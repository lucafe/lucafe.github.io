function [alpha,d_alpha] = SpectralAbscissa(E,A,TAU,A_prime,N,extra,varargin)
% SPECTRAL ABSCISSA 
%  infinitesimal generator approach for the linear autonomous DDAE: 
%       E x'(t)=sum_{i=0}^h A{i} x(t-TAU(i)).
%
%  [alpha,d_alpha] = SpectralAbscissa(E,A,TAU,A_prime,N,extra) 
%  evaluates the spectral abscissa and its gradient w.r.t. the parameters K,
%  given the number of the discretization points N and the deivatives of
%  the matrices A{i} w.r.t. to the component K(j), i.e. A_prime{j,i}. Since
%  the system is written in the form of DDAE of retarded type it is
%  important to indicate the precence of infinitive eigenvalue:
%       extra.Inf=length(E)-rank(E)
%  and the number of non-phisical zero eigenvalues which arise
%  differentiating the distributed delay term:
%       extra.zeros
%
%  Options:
%  'max_iter' - Maximum number of iteration used in the Newton's method to
%               correct the approximation of the rightmost eigenvalue.
%               (DEFAULT: 'max_iter', 10)
%  'accuracy' - Stop criterion for Newton's method: norm on residual
%               (DEFAULT: 'accuracy', 1e-12)
%  'test'     - The eigenvalues are computed if their modulo is less than
%               this value.
%               (DEFAULT: 'test', Inf)
%   
%  Method:
%  The code uses pseudospectral differentiation methods to discretize
%  the generator, it is an extension of the one described in 
%  [2, Theorem 2.1]. The original  pseudospectral differentiation methods 
%  for DDE is described in [3, Chapter 5] and originally in [4].
%  The notation used follows [1, 2]
%
%  The grandient of the spectral abscissa is computed using the right and
%  left eigenvector of the rightmost eigenvalue as described in [1,
%  Proposition 2]
%
%
%  Example of call:
%  [alpha] = SpectralAbscissa(E,A,TAU,A_prime,N,extra)
%            to compute only the spectral abscissa with DEFAULT option.
%  [alpha,d_alpha] = SpectralAbscissa(E,A,TAU,A_prime,N,extra)
%            to compute the spectral abscissa and its gradient.
%  [alpha,d_alpha] = SpectralAbscissa(E,A,TAU,A_prime,N,extra,...
%                    'max_iter', 0, 'accuracy', 1e-6, 'test', Inf)
%            to compute the spectral abscissa and its gradient with
%            specific options.
%
%  References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%  [2] E. Jarlebring, K. Meerbergen and W. Michiels, "A Krilov Method for 
%      the delay eigenvalue problem", SIAM J. Sci. Comput. 32(6):
%      3278-3300, 2010.
%  [3] D. Breda, S. Maset and R. Vermiglio, "Stability of linear delay
%      differential equations - A numerical approach with MATLAB", in
%      Control, Automation and Robotics, T. Basar, A. Bicchi and M. Krstic
%      eds., Springer, New York, 2015, ISBN 978-1-4939-2106-5.
%  [4] D. Breda, S. Maset and R. Vermiglio, "Approximation of eigenvalues
%      of evolution operators for linear retarded functional differential
%      equations", SIAM J. Numer. Anal. 50(3):1456-1483, 2012.
%  [5] L.N. Trefethen, "Spectral methods in Matlab", SIAM, 2000.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

n=length(E);    % dimension of the system 
h=length(TAU);  % number of delays

%% OPTIONS:
% definition of the options
options = inputParser;

% Default Options
default_max_iter=10;
    % maximum number of Newton iterations to correct characteristic roots
default_accuracy=1e-12;
    % stop criterion for Newton's method: norm on residual 
default_test=Inf; 
    % Max modulo of the rightmost eigenvalue
    % Inf is also an option

% Definition of the field 'solver', 'max_iter', and 'accuracy'
addOptional(options,'max_iter',default_max_iter,@isnumeric);
addOptional(options,'accuracy',default_accuracy,@isnumeric);
addOptional(options,'test',default_test,@isnumeric);
% The results of the options are saved in 
% options.Results.max_iter
% options.Results.accuracy
% options.Results.test
parse(options,varargin{:});

    
% BAND MATRIX L_N [2, Section 2.3]
L_N=zeros(N+1,N+1);
L_N(2,1:3)=[2 0 -1];
for i=3:1:N
    L_N(i,i-1:i+1)=[1/(i-1) 0 -1/(i-1)];
end
L_N(N+1,N:N+1)=[1/N 0];
L_N=(TAU(h)/4)*L_N;

% Pi_N matrix described in [2, Theorem 2.1].
Pi_N=kron(L_N,eye(n));
Pi_N(1:n,:)=kron(ones(1,N+1),E);

% Sigma_N matrix described in [2, Theorem 2.1].
Sigma_N=eye(n*(N+1)); 

% First row block of Sigma_N
Sigma_N(1:n,1:n)=zeros(n);
for i=1:N+1
    % Chebishev polynomial of the first kind 
    % Degree i-1 evaluated in (-2*TAU/TAU(h)+1)
    if i==1
        Cheb_sol=ones(1,h);
    elseif i==2
        Cheb_sol=(-2*TAU/TAU(h)+1);
        Cheb_1=(-2*TAU/TAU(h)+1);
        Cheb_2=ones(1,h);       
    else
        Cheb_sol=2*(-2*TAU/TAU(h)+1).*Cheb_1-Cheb_2;
        Cheb_2=Cheb_1;
        Cheb_1=Cheb_sol;
    end

    for j=1:h
        Sigma_N(1:n,((i-1)*n+1):(i*n))=Sigma_N(1:n,((i-1)*n+1):(i*n))+A{j}*Cheb_sol(j);
    end
end


%% Calculation of the rightsmost eigenvalue and its eigenvector
[V,D]=eig(Sigma_N,Pi_N);             % Generalized eigenvalue problem.
Lambda=diag(D); 
  % Elimination of extra zero or infinitives
    % zeros arise considering distributed delays
    % Inf arise considering a singular leading matrix
if nargin>5
    extra.Inf=extra.Inf-sum(isinf(Lambda));
    V=V(:,(~isinf(Lambda))); 
    Lambda=Lambda((~isinf(Lambda)));
    for i=1:extra.Inf
        [~,index_inf]=max(abs((Lambda)));
        V=V(:,[1:index_inf-1,index_inf+1:end]);
        Lambda=Lambda([1:index_inf-1,index_inf+1:end]);
    end
    for i=1:extra.zeros
        [~,index_zeros]=min(abs((Lambda)));
        V=V(:,[1:index_zeros-1,index_zeros+1:end]);
        Lambda=Lambda([1:index_zeros-1,index_zeros+1:end]);
    end
end
    V=V(:,(~isinf(Lambda))); 
    Lambda=Lambda((~isinf(Lambda)));
    V=V(:,(~isnan(Lambda))); 
    Lambda=Lambda((~isnan(Lambda)));

% Approximation correction    
test_L= find(abs(Lambda)<options.Results.test);
Lambda=Lambda(test_L);   
if isempty(Lambda)==1
    error('Increase the number of discretization points N, in order to obtain reliable solutions')
end

[~,index_r]=max(real(Lambda));      % Index of the spectral abscissa

lambda=Lambda(index_r);           % Rightmost eigenvalue;
v=V(1:n,index_r);                 % Right eigenvector of lambda
v0=v';

%% NEWTON METHODS
% Improvement of the calculation of the rightmost eigenvalue
Delta=@(lambda) E*lambda; % characteristic matrix
dDelta=@(lambda) E;       % derivative of the characteristic matrix w.r.t. lambda
for i=1:h
    Delta= @(lambda) Delta(lambda)-A{i}*exp(-lambda*TAU(i));
    dDelta=@(lambda) dDelta(lambda)+TAU(i)*A{i}*exp(-lambda*TAU(i));
end

Err=norm(Delta(lambda)*v);
step=0;
warning('off','MATLAB:nearlySingularMatrix')
while Err>options.Results.accuracy && step<options.Results.max_iter
    JF=[Delta(lambda), dDelta(lambda)*v; v0, 0];
    F=[Delta(lambda)*v; v0*v-1];
    dx=-JF\F;
    if sum(isnan(dx))==0  && sum(isinf(dx))==0
        v=v+dx(1:n);
        lambda=lambda+dx(end);
        Err=norm(Delta(lambda)*v);
        step=step+1;
    else
        break
    end
end
warning('on','MATLAB:nearlySingularMatrix')

alpha=real(lambda);% Spectral abscissa 

if nargout > 1
    v=v/norm(v,2);      % right eigenvector of lambda
    [U,~,~]=svd(Delta(lambda));
    u=U(:,end)';    % left eigenvector of lambda

    %% CALCULATION OF THE DERIVATIVE of the Spectral abscissa 
        % Evaluation of the derivatives of the characteristic metrix w.r.t
        % the components of the control parameter 
    k=size(A_prime,1);
    d_Lambda=zeros(n,n,k);
    for j=1:k
    for i=1:h
       d_Lambda(:,:,j)=d_Lambda(:,:,j)+A_prime{j,i}*exp(-lambda*TAU(i));
    end
    end   
    % derivative of lambda w.r.t. the components of the control parameter
    dlambda=zeros(k,1); 
    ds_denominator=u*dDelta(lambda)*v; 
    for j=1:k
        dlambda(j)=u*d_Lambda(:,:,j)*v/ds_denominator;
    end
    % derivative of the spectral abscissa w.r.t. the components of the control parameter
    d_alpha=real(dlambda);
end
end