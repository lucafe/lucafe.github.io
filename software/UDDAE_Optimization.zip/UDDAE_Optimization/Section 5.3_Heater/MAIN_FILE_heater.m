%% MAIN FILE 
% 
% This script was used to evaluate the values in the third to the sixth
% columns in Table 5, Section 5.3 of [1].
% The heat transfer model was already analyzed in [2, 3].
%
% NB The results in the mat-file differs from the ones in the paper, since
% they were obtained by a normal laptop imposing fewer sample points.
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at 
% http://www.cs.nyu.edu/overton/software/hanso/
% e.g. addpath('matlab/hanso') 
%
% REMEMBER TO LOAD the UDDAE_optimization
% free download at 
% http://twr.cs.kuleuven.be/research/software/delay-control/UDDAE_optimization/
% e.g. addpath('matlab/UDDAE_optimization') 
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%  [2] T. Vyhlidal, P. Zitek and K. Paulu, "Design, modelling and control
%      of the experimental heat transfer set-up", in Loiseau et al. (Eds.),
%      Topics in Time Delay Systems Analysis, Algorithms, and Control, Lecture
%      Notes in Control and Information Sciences, Springer, New York, 2009, pp.
%      303-314.
%  [3] W. Michiels, T. Vyhlidal, P. Zitek, "Control design for time-delay
%      systems based on quasi direct pole placement", Journal of Process Control
%      20: 337-343 (2010).
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% 1 - LOAD HANSO 
%      http://www.cs.nyu.edu/overton/software/hanso/
%addpath('/home/luca/hanso') 

%% 2 - LOAD UDDAE
% https://people.cs.kuleuven.be/~luca.fenzi/LF_Software.htm
% addpath('/home/luca/UDDAE')
addpath(fileparts(pwd)) 

%% 3 - SPECIFY YOUR MODEL
myUDDAE=cell(1,2);
myUDDAE{1}='UDDAE_heat_transfer_D1';
myUDDAE{2}='UDDAE_heat_transfer_D2';


%% 4 - SPECIFY THE PARAMETER OF THE OPTIMIZATION PROBLEM
M_opt=100;   % Number of sample that we use for the optimization problem
N=20;       % Number of discretization points used in the Infinitesimal
            % Generator approach
c=[0, 10, 100,1000];
            % a=[0, 1, 5, 10, 25, 50];   % Parameters of the objective function
            
%% 5 - SPECIFY THE PARAMETER OF THE POSTPROCESSING ANALYSIS
M_post=1000; % Number of sample that we use for the postprocessing analysis

% INITIALIZATION
K=cell(1,2);
f=cell(1,2);
Mean=cell(1,2);        % Mean spectral abscissa
Variance=cell(1,2);    % Variance spectral abscissa
d_Mean=cell(1,2);      % Derivative mean spectral abscissa w.r.t. K
d_Variance=cell(1,2);  % Derivative Variance spectral abscissa w.r.t. K
alpha=cell(1,2);       % Nominal value of the spectral abscissa
d_alpha=cell(1,2);     % Nominal value of the gradient of the spectral abscissa

for uddae=1:2
    eval(myUDDAE{uddae})
    K{uddae}=zeros(k,length(c));   
    f{uddae}=zeros(1,length(c));   
    Mean{uddae}=zeros(1,length(c));    
    Variance{uddae}=zeros(1,length(c));   
    d_Mean{uddae}=zeros(k,length(c));  
    d_Variance{uddae}=zeros(k,length(c));  
    alpha{uddae}=zeros(1,length(c));       
    d_alpha{uddae}=zeros(k,length(c));
    for ci=1:length(c)
        % Settings for HANSO
        [pars,options] = Optimization_myUDDAE(myUDDAE{uddae}, c(ci), M_opt, N);
        % HANSO optimization
        [K{uddae}(:,ci),f{uddae}(ci)] = hanso(pars, options); 
        % Postprocessing analysis
        if uddae==1 && ci==1
            [Mean{uddae}(ci),Variance{uddae}(ci), d_Mean{uddae}(:,ci), d_Variance{uddae}(:,ci), SpAbscissa]  =  MomentaSpectralAbscissa(myUDDAE{uddae}, K{uddae}(:,ci), M_post, N);
        else
            [Mean{uddae}(ci),Variance{uddae}(ci), d_Mean{uddae}(:,ci), d_Variance{uddae}(:,ci)]  =  MomentaSpectralAbscissa(myUDDAE{uddae}, K{uddae}(:,ci), M_post, N);
        end
        % Nominal Value
        [alpha{uddae}(ci),d_alpha{uddae}(:,ci)] =  NominalValue(myUDDAE{uddae}, K{uddae}(:,ci), N);
    end
end

%% REMARK 
% Mean+c.Variance should be comparable with f otherwise you should re-run
% the optimization function with more sampling points.

save('1st_RESULTS_Heat_Transfer.mat','myUDDAE','c','M_opt','M_post','N',...
    'Mean','Variance','K','f','d_Mean','d_Variance','alpha','d_alpha');

%% 6 - CORRECTIONS
% The first results often do not satisfy criterion (31) in [1, Section 5.3]
% hence we re-run the previous step initializing HANSO on all optimal gain
% values previously found for each value of c.


%% 4 - SPECIFY THE PARAMETER OF THE OPTIMIZATION PROBLEM
M_opt2=500;   % Number of sample that we use for the optimization problem
N2=20;       % Number of discretization points used in the Infinitesimal
            % Generator approach
c=[0, 10, 100,1000];
            % a=[0, 1, 5, 10, 25, 50];   % Parameters of the objective function
            
%% 5 - SPECIFY THE PARAMETER OF THE POSTPROCESSING ANALYSIS
M_post2=2000; % Number of sample that we use for the postprocessing analysis

% INITIALIZATION
K2=cell(1,2);
f2=cell(1,2);
Mean2=cell(1,2);        % Mean spectral abscissa
Variance2=cell(1,2);    % Variance spectral abscissa
d_Mean2=cell(1,2);      % Derivative mean spectral abscissa w.r.t. K
d_Variance2=cell(1,2);  % Derivative Variance spectral abscissa w.r.t. K
alpha2=cell(1,2);       % Nominal value of the spectral abscissa
d_alpha2=cell(1,2);     % Nominal value of the gradient of the spectral abscissa

for uddae=1:2
    eval(myUDDAE{uddae})
    K2{uddae}=zeros(k,length(c));   
    f2{uddae}=zeros(1,length(c));   
    Mean2{uddae}=zeros(1,length(c));    
    Variance2{uddae}=zeros(1,length(c));   
    d_Mean2{uddae}=zeros(k,length(c));  
    d_Variance2{uddae}=zeros(k,length(c));  
    alpha2{uddae}=zeros(1,length(c));       
    d_alpha2{uddae}=zeros(k,length(c));
    % initializing HANSO on all optimal gain values previously found for each value of c.
        setting.x0=K{uddae};
    for ci=1:length(c)
        % Settings for HANSO
        [pars,options] = Optimization_myUDDAE(myUDDAE{uddae}, c(ci), M_opt2, N2,setting);
        % HANSO optimization
        [K2{uddae}(:,ci),f2{uddae}(ci)] = hanso(pars, options); 
        % Postprocessing analysis
        [Mean2{uddae}(ci),Variance2{uddae}(ci), d_Mean2{uddae}(:,ci), d_Variance2{uddae}(:,ci)]  =  MomentaSpectralAbscissa(myUDDAE{uddae}, K2{uddae}(:,ci), M_post2, N2);
        % Nominal Value
        [alpha2{uddae}(ci),d_alpha2{uddae}(:,ci)] =  NominalValue(myUDDAE{uddae}, K2{uddae}(:,ci), N2);
    end
end

%% REMARK 
% Mean+c.Variance should be comparable with f otherwise you should re-run
% the optimization function with more sampling points.

save('2nd_RESULTS_Heat_Transfer.mat','myUDDAE','c','M_opt','M_post','N',...
    'Mean','Variance','K','f','d_Mean','d_Variance','alpha','d_alpha',...
    'M_opt2','M_post2','N2',...
    'Mean2','Variance2','K2','f2','d_Mean2','d_Variance2','alpha2','d_alpha2');

