function [Xi] = QuasiMonteCarlo(PCE,germ,M)
% QUASI MONTE CARLO 
% [Xi]=QuasiMonteCarlo(PCE,germ,M) generates M samples of the random
%   vector with D independent components, which are defined by the
%   polinomial chaos expansions PCE{i} associated to the germ germ{i}
%   for i=1,...,D.
%   In particular it samples the random input using quasi random or low
%   discrepancy method. In particular it uses the halton sequence if the
%   stochastic dimension D is less than 6 otherwise it uses the sobolset,
%   as described in [2]
%   To compute the sample of the exponential and normal distributions we
%   use the inversion method with the analytic and the approximation of the
%   inverse of the cumulative density function.
%   The approximation of the inverse of the cdf of the normal is computed
%   with norminv.
%
% Input
% PCE  - cell with size (1,D), the ith cell defines the polynomial chaos
%      expansion w.r.t. the germ germ{i}
% germ - cell with size (1,D) every cell can be:
%     'n' -> Standard Normal Distribution (mean=0, standard deviation=1)
%     'e' -> Standard Exponential Distribution (rate parameter=mean=1)
%     'u' -> Uniform Distribution in the interval [-1,1]
%	any positive number -> Striclty dependent distribution
%		e.g. germ{j}=i; the j random parameter use the same 
% 		realizations of the i-th (complete dependence).
% M    - number of sample that we want to generate
% 
% Output
% Xi - vector with size (D,M) that contains all the samples of the random
%      inputs
%
% Notation
% To sample we use the three term recurrence:
% new=      An       *stepn-Cn*stepn_1
%
%  References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%  [2]  W. J. Morkof and R. E. Caflish "Quasi Monte Carlo Integration", 
%       J. Comput. Phys. 122: 218-230, 1995.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi


%% STOCHASTIC DIMENSION OF THE PROBLEM - D
if length(PCE)==length(germ)
    D=length(PCE);
else
    error('The cells PCE and germ do not have the same dimension.')
end

%% QUASI MONTE CARLO SAMPLING
if D<=6     % Halton quasi-random point set
    p = haltonset(D,'Skip',1e3,'Leap',1e2);
    p = scramble(p,'RR2');
    Xi=net(p,M)';
else  % Sobol quasi-random point set
    p = sobolset(D,'Skip',1e3,'Leap',1e2);
    p = scramble(p,'MatousekAffineOwen');
    Xi=net(p,M)';
end


% DEPENDENT COMPONENT
for i=2:D
    if isnumeric(germ{i}) && i>germ{i}
        Xi(i,:)=Xi(germ{i},:);
        germ{i}=germ{germ{i}};
    end
end

for i=1:D
    %% Probabilistic Hermite - PCE
    if strcmp(germ{i},'n')==1   % germ=NORMAL
        sample=norminv(Xi(i,:));
        stepn_1=ones(1,M);
        stepn=sample;
        Xi(i,:)=PCE{i}(1)*stepn_1+PCE{i}(2)*stepn;
        for j=2:length(PCE{i})-1
                % An=(1*sample+0);
                % Cn=j-1;
                new=sample.*stepn-(j-1)*stepn_1;
                Xi(i,:)=PCE{i}(j+1)*new+Xi(i,:);
                % UPDATING
                stepn_1=stepn;
                stepn=new;
        end
    %% Laguerre - PCE
    elseif strcmp(germ{i},'e')==1  % germ=EXPONENTIAL
        sample=-log(Xi(i,:)); 
        
        stepn_1=ones(1,M);
        stepn=ones(1,M)-sample;
        Xi(i,:)=PCE{i}(1)*stepn_1+PCE{i}(2)*stepn;
        for j=2:length(PCE{i})-1
                An=(2*j-1-sample)/j;
                Cn=(j-1)/j;
                new=An.*stepn-Cn*stepn_1;
                
                Xi(i,:)=PCE{i}(j+1)*new+Xi(i,:);
                
                % UPDATING
                stepn_1=stepn;
                stepn=new;
        end
    %% Legendre shifted in the interval [0,1] - PCE    
    elseif strcmp(germ{i},'u')==1  % germ=UNIFORM 
        sample=Xi(i,:);
        
        stepn_1=ones(1,M);
        stepn=2*sample-ones(1,M);
        Xi(i,:)=PCE{i}(1)*stepn_1+PCE{i}(2)*stepn;
            for j=2:length(PCE{i})-1
                An=(4*(j-1) +2)/j*sample-(2*(j-1) +1)/j;
                Cn=((j-1))/(j);
                new=An.*stepn-Cn*stepn_1;

                Xi(i,:)=PCE{i}(j+1)*new+Xi(i,:);
                % UPDATING
                stepn_1=stepn;
                stepn=new;
            end
    else
        error('The %d-th component of the germ is not well defined.\n', i);
        break
    end
end
end

