% SCRIPT myUDDAE='UDDAE_system_23';
%
% System (23) described in [2, Section 4.3, Example 2] first appeared in
% [1].
%
% References:
%  [1] W. Michiels, K. Engelborghs, P. Vansevenant, D. Roose, "Continuous 
%      pole placement for delay equations", Automatica 38:
%      747-761, 2002.
%  [2] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% SIZE OF THE LINEAR SYSTEM 
n=2;

%% NUMBER OF DISCRETE DELAYS
h=2;

%% LENGTH OF THE CONTROL PARAMETER
k=1;

%% STOCHASTIC DIMENSION OF THE PROBLEM
D=1;

%% DESCRIPTION OF THE RANDOM PARAMETERS
PCE=cell(1,D);
germ=cell(1,D);
    germ{1}='u';    % omega
    PCE{1}=[0.9,1.1];
    
    %% NUMBER OF zeros & INF EIGENVALUES WHICH MUST BE DELETED
extra.Inf=0;    % n-rank of the leading matrix
extra.zeros=0;  % number of non-physical zeri eigenvalues 
                % which arise differentiating the distributed delay.
    
%% LEADING MATRIX
E=eye(2);

%% DISCRETE DELAY TERMS
TAU=@(omega) [0,1]; %INPUT discrete delays row vector TAU=[tau_{1}(omega),...,tau_{h}(omega)]>=0

A=cell(1,h);
A{1}=@(omega,K) [0,1;...
                -omega(1)^2,0];  
A{h}=@(omega,K) [0,0;...
                 K(1)*omega(1)^2,0]; 

%% DERIVATIVES OF A{i} w.r.t K
A_prime=cell(k,h);
    % Derivive of A{i} w.r.t. K(1)
A_prime{1,1}=@(omega,K) zeros(2);
A_prime{1,2}=@(omega,K) [0,0;...
    omega(1)^2,0];
