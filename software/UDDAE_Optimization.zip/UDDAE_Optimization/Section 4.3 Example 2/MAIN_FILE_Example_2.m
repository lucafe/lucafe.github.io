%% MAIN FILE 
% 
% This script was used to plot both panes of Figure 6 [1, Section 4.3, Example 2]
% (Bifurcation analysis and approximation of the objective function).
% The system (22) is described in UDDAE_system_22
%
% REMEMBER TO LOAD the UDDAE_optimization
% free download at 
% http://twr.cs.kuleuven.be/research/software/delay-control/UDDAE_optimization/
% e.g. addpath('matlab/UDDAE_optimization') 
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi


%% 2 - LOAD UDDAE
% https://people.cs.kuleuven.be/~luca.fenzi/LF_Software.htm
% addpath('/home/luca/UDDAE')
addpath(fileparts(pwd))

%% 3 - SPECIFY YOUR MODEL
myUDDAE='UDDAE_system_22';
eval(myUDDAE)

%% 4 - INITIALIAZATION
N=20;

%% 4- BIFURCATION ANALYSIS VARYING K FIXING omega
omega=0.9:0.001:1.1;
K=0.6:0.001:0.85; 
alpha=zeros(length(omega),length(K));
for ki=1:length(K)
    for oj=1:length(omega)
        TAU_D=TAU(omega(oj));
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        for i=1:h
            A_D{i}=A{i}(omega(oj),K(ki));
            for j=1:k
                A_prime_D{j,i}=A_prime{j,i}(omega(oj),K(ki));
            end
        end
        [alpha(oj,ki)] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N,extra);

    end
end

%% Left pane - FIGURE 6
hold on
h=0;
for j=1:40:length(omega)
    plot(K,[alpha(j,1:45),NaN*ones(1,14),alpha(j,60:end)],'LineWidth',2);
    h=h+1;
    text(K(50),alpha(j,50),num2str(h))
end
hold off 
xlabel('$K$', 'Interpreter','Latex');
ylabel('$E(\alpha(\omega,K))$', 'Interpreter','Latex');


%% Right Pane -Figure 6
figure 
plot(K,mean(alpha),'Color',[0.4,0.4,0.4],'LineStyle','-.','LineWidth',2);
hold on 
s=mean(alpha(1:40:length(omega),:));
for j=1:40:length(omega)
    [~,index]=min(alpha(j,:));
    plot(K(index),s(index),'o','LineWidth',2);
end
plot(K,mean(alpha(1:40:length(omega),:)),'black','LineWidth',2);
xlabel('$K$', 'Interpreter','Latex');
ylabel('$E(\alpha(\omega,K))$', 'Interpreter','Latex');

