function [alpha,d_alpha] =  NominalValue(myUDDAE, K, N, varargin)
%NOMINAL VALUE
% Compute the spectral abscissa (alpha) and its gradient w.r.t. K (d_alpha)
% on the uncertain model 'myUDDAE' fixed the random vector on the mean
% value.
%
% Input:    
% myUDDAE - script where the model is defined,
% K       - control parameter
% N       - Number of discretization points used in the Infinitesimal
%   Generator approach
% 
% Output
% alpha   - Mean of the spectral abscissa
% d_alpha - Gradient of the spectral abscissa w.r.t. K
%
% Options:
% 'max_iter' - Maximum number of iteration used in the Newton's method to
%               correct the approximation of the rightmost eigenvalue.
%               (DEFAULT: 'max_iter', 10)
% 'accuracy' - Stop criterion for Newton's method: norm on residual
%               (DEFAULT: 'accuracy', 1e-14)
% 'test'     - The eigenvalues are computed if their modulo is less than
%               this value.
%               (DEFAULT: 'test', Inf)
% 'verification' - Verification test to check if the spectral
%               abscissa is coorectly evaluated 
%               0  - No verification test
%               1  - Test with N+n points 
%               (DEFAULT: 'verification', 1)
%
%  Example of call:
%  [alpha] = NominalValue(myUDDAE, K, N)
%            to compute only the spectral abscissa with DEFAULT option.
%  [alpha,d_alpha] = NominalValue(myUDDAE, K, N)
%            to compute the spectral abscissa and its gradient.
%  [alpha,d_alpha] = NominalValue(myUDDAE, K, N,...
%                    'max_iter', 0, 'accuracy', 1e-6, 'test', Inf)
%            to compute the spectral abscissa and its gradient with
%            specific options.
%  [alpha,d_alpha] = NominalValue(myUDDAE, K, N,...
%                    'max_iter', 0, 'accuracy', 1e-6, 'test', Inf,...
%                    'verification',1)
%           Check the correctness of the spectral abscissa computed
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

eval(myUDDAE);

%% OPTIONS:
% definition of the options
options = inputParser;

% Default Options
default_max_iter=10;
    % maximum number of Newton iterations to correct characteristic roots
default_accuracy=1e-14;
    % stop criterion for Newton's method: norm on residual 
default_test=Inf; 
    % Max modulo of the rightmost eigenvalue
    % Inf is also an option
default_verification=1;

% Definition of the field 'solver', 'max_iter', and 'accuracy'
addOptional(options,'max_iter',default_max_iter,@isnumeric);
addOptional(options,'accuracy',default_accuracy,@isnumeric);
addOptional(options,'test',default_test,@isnumeric);
addOptional(options,'verification',default_verification,@isnumeric);
% The results of the options are saved in 
% options.Results.max_iter
% options.Results.accuracy
% options.Results.test
% options.Results.verification
parse(options,varargin{:});

if options.Results.verification<0 || options.Results.verification>2
    error('Unvalid value for verification option, the admissible entry for verification are 0, or 1')
end



mean_values=zeros(1,D); % mean values of the random vector omega
for d=1:D
    mean_values(d)=PCE{d}(1);
end

% Setting the parameters 
TAU_D=TAU(mean_values);
A_D=cell(1,h);
A_prime_D=cell(k,h);
for i=1:h
   A_D{i}=A{i}(mean_values,K);
   for j=1:k
      A_prime_D{j,i}=A_prime{j,i}(mean_values,K(:));
   end
end
[alpha,d_alpha] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N,extra,...
            'max_iter',options.Results.max_iter,'accuracy',options.Results.accuracy,'test',options.Results.test);
% VERIFICATION 
% Check if the rightmost eigenvalue is evaluated using N discretization
% point in the interval [-tau_h,0].
if options.Results.verification>0
        [Trial] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N+n,extra,...
            'max_iter',options.Results.max_iter,'accuracy',options.Results.accuracy,'test',options.Results.test+1);
        if Trial-alpha>options.Results.accuracy*100 
            warning('Increase the number of discretization points N in order to correctly evaluate the spectral abscissa')
        end
end        

