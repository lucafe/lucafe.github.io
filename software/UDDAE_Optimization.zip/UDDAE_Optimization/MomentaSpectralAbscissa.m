function [Mean,Variance, d_Mean, d_Variance, SpAbscissa] =  MomentaSpectralAbscissa(myUDDAE, K, M, N, varargin)
%MOMENTA SPECTRAL ABSCISSA 
%  Using Quasi Monte Carlo Methods, evaluates a sample of the random
%  inputs, and for every realization it compute the associated realization
%  of the spectral abscissa and its gradient through the Infinitesimal
%  approach corrected by Newton Method. 
%
% Input:    
% myUDDAE - script where the model is defined,
% K       -  control parameter
% M       -  number of samples for Quasi Monte Carlo Methods
% N       -  Number of discretization points used in the Infinitesimal
%         Generator approach
% 
% Output
% Mean       - Mean of the spectral abscissa
% Variance   - Variance of the spectral abscissa
% d_Mean     - Derivative of the mean of the spectral abscissa w.r.t. the
%            control parameters K
% d_Variance - Derivative of the mean of the spectral abscissa w.r.t. the
%            control parameters K
% SpAbscissa - Plot of the probability density function of the spectral
%            abscissa (Optional Output)
%
% Options:
% 'max_iter'     - Maximum number of iteration used in the Newton's method 
%                to correct the approximation of the rightmost eigenvalue.
%                (DEFAULT: 'max_iter', 10)
% 'accuracy'     - Stop criterion for Newton's method: norm on residual
%                (DEFAULT: 'accuracy', 1e-14)
% 'test'         - The eigenvalues are computed if their modulo is less than
%                this value.
%                (DEFAULT: 'test', Inf)
% 'verification' - Verification test to check if the spectral
%               abscissa is coorectly evaluated 
%               0  - No verification test
%               1  - The maximum spectral abscissa of M samples is evaluated
%               2  - The maximum and the minimum spectral abscissa of M 
%                   samples is evaluated
%               (DEFAULT: 'verification', 1)
%
%
%  Example of call: 
%  [Mean,Variance, d_Mean, d_Variance] =  MomentaSpectralAbscissa('myUDDAE', K, M, N)
%        Basic command to compute Mean, Variance and their gradient of the
%        system 'myUDDAE' with controller K, M samples and N discretization
%        points (Default options)
%  [Mean,Variance, d_Mean, d_Variance,SpAbscissa] =  MomentaSpectralAbscissa('myUDDAE', K, M, N)
%        It plots also the probability density function of the spectral
%        abscissa and you can investigated further proprieties analyzing
%        SpAbscissa.xi and SpAbscissa.pdf (Default options)
%  [Mean,Variance, d_Mean, d_Variance,SpAbscissa] =  MomentaSpectralAbscissa('myUDDAE', K, M, N,...
%       'max_iter', 0, 'accuracy', 1e-6, 'test', Inf, 'verification', 0)
%        To personalize the different options.
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi


% DESCRIPTION OF THE MODEL
eval(myUDDAE);

%% OPTIONS:
% definition of the options
options = inputParser;

% Default Options
default_max_iter=10;
    % maximum number of Newton iterations to correct characteristic roots
default_accuracy=1e-14;
    % stop criterion for Newton's method: norm on residual 
default_test=Inf; 
    % Max modulo of the rightmost eigenvalue
    % Inf is also an option
default_verification=2;

% Definition of the field 'solver', 'max_iter', and 'accuracy'
addOptional(options,'max_iter',default_max_iter,@isnumeric);
addOptional(options,'accuracy',default_accuracy,@isnumeric);
addOptional(options,'test',default_test,@isnumeric);
addOptional(options,'verification',default_verification,@isnumeric);

% The results of the options are saved in 
% options.Results.max_iter
% options.Results.accuracy
% options.Results.test
% options.Results.verification
parse(options,varargin{:});

if options.Results.verification<0 || options.Results.verification>3
    error('Unvalid value for verification option, the admissible entry for verification are 0, 1, or 2')
end

% Sampling the random inputs
[Xi] = QuasiMonteCarlo(PCE,germ,M);

% Initialization
alpha=NaN(1,M);
d_alpha=NaN(k,M);

%% Inizialization to use the parallelized for loop of MATLAB
E=E; A=A; TAU=TAU; A_prime=A_prime; h=h; k=k; extra=extra;

parfor r=1:M
        % Negative values of the delays must be deleted.
    if sum(TAU(Xi(:,r))<0)>0 
       warning('The %dth sample of the delays presents negative values\n This realization is neglected', r)
    else
        % We fix the realization Xi(:,r) and we compute the spectral
        % abscissa and its derivative for the deterministic DDAE associated 
        % to this realization of the random input
        
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        % The realization of the delay is sorted
        [TAU_D,order]=sort(TAU(Xi(:,r)));
        for i=1:h
            A_D{i}=A{order(i)}(Xi(:,r),K);
            for j=1:k
                A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r),K);
            end
        end
        [alpha(r),d_alpha(:,r)] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N,extra,...
            'max_iter',options.Results.max_iter,'accuracy',options.Results.accuracy,'test',options.Results.test);
    end
end

% Delection of Inf or NaN derivatives
% if the delays are negative we enter in this if condition
if sum(sum(isnan(d_alpha)))+sum(sum(isinf(d_alpha)))>0
    warning('Neglected %d NaN and %d Inf in the calculation of the derivative', length(Xi(:,all(isnan(d_alpha)))), length(Xi(:,all(isinf(d_alpha)))));
    r=size(d_alpha);
    index=zeros(1,r(2));
    for i=1:r(1)
        index=index+isnan(d_alpha(i,:))+isinf(d_alpha(i,:));
    end
    index=(index>0);
    for j=1:r(2)
        if index(j)==1
            d_alpha(:,j-sum(index(1:j))+1)=[];
            alpha(j-sum(index(1:j))+1)=[];
        end
    end
end

Mean=mean(alpha);
Variance=var(alpha);

d_Mean=zeros(1,k);
d_Variance=zeros(1,k);
for j=1:k
    d_Mean(j)=mean(d_alpha(j,:));
    d_Variance(j)=2*(mean(alpha.*d_alpha(j,:))-Mean*d_Mean(j));
end

%% Plot of the probability density funciton of the spectral abscissa
if nargout==5
    [SpAbscissa.pdf,SpAbscissa.xi]=ksdensity(alpha);
    plot(SpAbscissa.xi,SpAbscissa.pdf);
    xlabel('$x$', 'Interpreter', 'latex')
    ylabel('$p_{\alpha}(x)$', 'Interpreter', 'latex')
    title('Spectral Abscissa')
end

% VERIFICATION 
% Check if the rightmost eigenvalue is evaluated using N discretization
% point in the interval [-tau_h,0].
if options.Results.verification>0
    % Comparison with the maximal spectral abscissa found
    [~,r]=max(alpha);
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        % The realization of the delay is sorted
        [TAU_D,order]=sort(TAU(Xi(:,r)));
        for i=1:h
            A_D{i}=A{order(i)}(Xi(:,r),K);
            for j=1:k
                A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r));
            end
        end
        [Trial] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N+n,extra,...
            'max_iter',options.Results.max_iter,'accuracy',options.Results.accuracy,'test',options.Results.test+1);
        if Trial-alpha(r)>options.Results.accuracy*100 
           warning('The difference between the spectral abscissa evaluated with N discretization points and N+n is %1.10f\n Increase the discretization point.', Trial-alpha(r))
        end
        if options.Results.verification>1
            % Comparison with the minimal spectral abscissa found
            [~,r]=min(alpha);
                A_D=cell(1,h);
                A_prime_D=cell(k,h);
                % The realization of the delay is sorted
                [TAU_D,order]=sort(TAU(Xi(:,r)));
                for i=1:h
                    A_D{i}=A{order(i)}(Xi(:,r),K);
                    for j=1:k
                    A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r));
                    end
                end
            [Trial] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N+n,extra,...
            'max_iter',options.Results.max_iter,'accuracy',options.Results.accuracy,'test',options.Results.test+1);
            if Trial-alpha(r)>options.Results.accuracy *100
                 warning('The difference between the spectral abscissa evaluated with N discretization points and N+n is %1.10f\n Increase the discretization point.', Trial-alpha(r))
            end
        end
end
end
