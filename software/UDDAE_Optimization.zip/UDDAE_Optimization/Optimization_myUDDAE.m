function [pars,options] = Optimization_myUDDAE(myUDDAE, c, M, N, setting)
%OPTIMIZATION myUDDAE
%  settings to use HANSO: Hybrid Algorithm for Non-Smooth Optimization to
%  minimize the objective function:
%  Mean(alpha)+a*Variance(alpha)
%  where alpha is the spectral abscissa
%
% Input:    
% myUDDAE - script where the model is defined,
% c       - parameter of the objective function
% M       - number of samples for Quasi Monte Carlo Methods
% N       - Number of discretization points used in the Infinitesimal
%           Generator approach
% setting - additional information
%
% Output:
% pars    - model for HANSO
% options - options for HANSO
% 
% Option for HANSO:
% setting.normtol         - [Default: 1/M convergence rate of QMC]
%           Termination tolerance for smallest vector in 
%           convex hull of saved gradients
% setting.starting_vector - [Default: 10]
%           Number of starting point for the initialization of BFGS phase
% setting.x0              - [Default: randn]
%           Columns are one or more starting vector of variables, 
%           used to intialize the BFGS phase of the algorithm
% setting.maxit           - [Default: 500]
%           Max number of iterations for each BFGS starting point
% setting.samprad         - [Default: [10  1  0.1]*setting.evaldist]
%                           [] (no gradient sampling)
%           Sampling radii for gradient sampling
% setting.evaldist        - [Default: 1/sqrt(M) convergence rate of QMC]
%           Evaluation distance used to determine which gradients to use in
%           this computation  
%
% Option for the computation of the spectral abscissa
% setting.max_iter     - Maximum number of iteration used in the Newton's 
%               method to correct the approximation of the rightmost eigenvalue.
%               (DEFAULT: 10)
% setting.accuracy     - Stop criterion for Newton's method: norm on residual
%               (DEFAULT: 1e-14)
% setting.test         - The eigenvalues are computed if their modulo is less than
%               this value.
%               (DEFAULT: Inf)
% setting.verification - Verification test to check if the spectral
%               abscissa is coorectly evaluated 
%               0  - No verification test
%               1  - The maximum spectral abscissa of M samples is evaluated
%               2  - The maximum and the minimum spectral abscissa of M 
%                   samples is evaluated
%               (DEFAULT: 1)
%
% Example of call:
%    [pars,options] = Optimization_myUDDAE(myUDDAE, c, M, N);
%    [K, f] = hanso(pars, options); 
%           K optimal value of the control parameter
%           f optimal value found of the objective function
%    [pars,options] = Optimization_myUDDAE(myUDDAE, c(i), M, N, setting);
%           In setting it is possible to set additional properties of the
%           optimization
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% EVALUATION OF THE MODEL
eval(myUDDAE)


%% OPTIONS FOR HANSO:
if nargin < 5
    setting = [];
end

% options.normtol: termination tolerance for smallest vector in 
%          convex hull of saved gradients
%          (default: 1e-4)
if isfield(setting, 'normtol')==1 
   options.normtol=setting.normtol;
else
   options.normtol=1/M; % [Default: Convergence rate of the QMC]
end

% options.starting_vector: number of starting vector
% options.x0: columns are one or more starting vector of variables, 
%          used to intialize the BFGS phase of the algorithm
%          (default: 10 starting points are generated randomly)

if isfield(setting, 'starting_vector')==1 
   starting_vector=setting.starting_vector;
else 
    starting_vector=10;
end

if isfield(setting, 'x0')==1 
   options.x0=setting.x0;
else 
    options.x0 = randn(k, starting_vector);
    if extra.zeros>0
        while sum(options.x0==0)>0
            options.x0=options.x0+randn(k, starting_vector).*(abs(options.x0)<1.0e-12);
        end
    end
end

% options.maxit: max number of iterations for each BFGS starting point
%          (default: 1000)
if isfield(setting, 'maxit')==1 
   options.maxit=setting.maxit;
else 
   options.maxit=500;
end

% options.samprad: sampling radii for gradient sampling
%          (default: [10  1  0.1]*options.evaldist if pars.nvar <= 100, 
%           otherwise [] (no gradient sampling) 
if isfield(setting, 'samprad')==1 
   options.samprad=setting.samprad;
end

% options.evaldist: evaluation distance used to determine which
%          gradients to use in this computation 
%          (default: 1e-4)

if isfield(setting, 'evaldist') ==1
   options.evaldist=setting.evaldist;
else
   options.evaldist=1/sqrt(M); % [Default: Convergence rate of the QMC]
   % 1/sqrt(M)
end


% EXTRA OPTIONS OF HANSO
%      options.nvec: 0 for full BFGS matrix update in BFGS phase, otherwise 
%           number of vectors to save and use in the limited memory updates
%          (default: 0)
%      options.fvalquit: quit if f drops below this value 
%          (default: -inf)
%      options.cpumax: quit if cpu time in seconds exceeds this
%          (default: inf)
%      options.prtlevel: print level, 0 (no printing), 1, or 2 (verbose)
%          (default: 1)
%% OPTIONS FOR SPERCTRAL ABSCISSA

% maximum number of Newton iterations to correct characteristic roots
if isfield(setting, 'max_iter')==1 
   pars.max_iter=setting.max_iter;
else
   pars.max_iter=10; % DEFAULT
end

% stop criterion for Newton's method: norm on residual
if isfield(setting, 'accuracy')==1 
   pars.accuracy=setting.accuracy;
else
   pars.accuracy=1e-14; % DEFAULT
end

% Max modulo of the rightmost eigenvalue
if isfield(setting, 'test')==1
   pars.test=setting.test;
else
   pars.test=Inf; % DEFAULT
end

% Max modulo of the rightmost eigenvalue
if isfield(setting, 'verification')==1
   pars.verification=setting.verification;
else
   pars.verification=1; % DEFAULT
end
if  pars.verification<0 || pars.verification>3
    error('Unvalid value for setting.verification, the admissible entry are 0, 1, or 2')
end


%% PARS FOR HANSO
[Xi] = QuasiMonteCarlo(PCE,germ,M);% Sampling the random inputs

pars.nvar = k;                     % Dimension of the control parameter 
                                   %   (length(K))
pars.fgname='ObjFunction_myUDDAE'; % Objective function 
pars.model=myUDDAE;                % Model
pars.Xi=Xi;                        % Fixed grid 
pars.c=c;                          % Parameter of the objective function 
pars.N=N;                          % Discretization of the IG
pars.M=M;                          % Number of sample of the optimization

end


