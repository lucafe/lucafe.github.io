function [f,df] = ObjFun_FloMU_Large(K,obj)
%ObjFun_FloMU_Large - Objective Function for stability optimitization 
%   with HANSO for large scale problem
%   This function describes the objective function for the minimization of
%   the largest in modulus Floquet multipliers by HANSO
%   See optFloMu for further information
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

if obj.timing==1, TimeOBJ=tic; end
%% DISCRETIZATION
[mu,v] =  eigsFloMU(obj.ptds,    obj.M, K, obj.algorithm,       1, obj.opts);
[muc,u] = eigsFloMU(obj.ptdsadj, obj.M, K, obj.algorithm, obj.rho, obj.opts);


%% PAIRING
[pairing,ind]=min(abs(mu-conj(muc)));
muc=muc(ind); u=u(:,ind);
if pairing>obj.pairing,    warning(['Error pairing=',num2str(pairing),' K=',num2str(transpose(K))]);
end

%% BROYDEN CORRECTIONS
if obj.options.maxit>0

	if isreal(mu)==1, 
   		mu=mu+1i*eps;
	end
	if isreal(muc)==1, 
   		muc=muc+1i*eps;
	end

    initial.H=speye(obj.ptds.dim*obj.ptds.N+1,obj.ptds.dim*obj.ptds.N+1); 
    initial.v=v;
    [mu,v,out] = cFloMU(obj.ptds,K,mu,obj.options,initial);
    if out>0,  warning(['Broyden''s correction did not converge, K=', num2str(transpose(K))]);
    end
    
    initial.v=u;
    [muc,u,out] = cFloMU(obj.ptdsadj,K,muc,obj.options,initial);
    if out>0,    warning(['Broyden''s correction for transpose problem did not converge, K=', num2str(transpose(K))]);
    end
end

if abs(mu-conj(muc))>obj.pairing,    warning(['Error between Floquet Multipliers=', num2str(abs(mu-conj(muc))), ' K=', num2str(transpose(K))]);
end
mu=(mu+conj(muc))/2;
u=obj.ptdsadj.R*u;

%% DERIVATIVE FLOQUET MULTIPLIER
[demu] = deFloMU(obj.ptds,K,mu,obj.options,v,u); 

%% OBJECTIVE FUNCTION and ITS DERIVATIVE
f=abs(mu)^2;
df=2*real(conj(mu)*demu);

if obj.timing==1, t=toc(TimeOBJ);
fprintf(['f=',num2str(f),' df=',num2str(norm(df)),' evaluated in ',num2str(t),'sec','for K=', num2str(transpose(K)),'\n']);
end

end

