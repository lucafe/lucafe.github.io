function [ptds,options,ptdsadj] = ptds_create(A,tau,T,dA,varargin)
%Periodic Time Delay system CREATE
% ptds_create constructs a structures for the stability and stabilization 
% of periodic time delay systems, and test the correctness of the model. 
%
%% INPUT:
% A   - cell with the system matrices in handle form. 
% tau - vector with the delays associated to each system matrix.
% T   - period of the system matrices.
% dA  - cell with the system matrices derivatives w.r.t. the controller parameters K 
%
% tol_rat (optional) - Tolerance for the approximation ration delays to
%                      period.
%% OUTPUT:
% ptds    - structure containing the system properties
% options - structure containing all the offset parameters for the
%           computation of the Floquet multipliers
% ptdsadj - dual periodic time delay system 
%           (used for large-scale problems)

%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.


%% ADDITIONAL INPUT:
info = inputParser;

default_mass=0;             % Mass
default_stiff=0;            % Stiff
default_cf=1;              % Tolerance RAT - Rational fraction approximation
default_rat=0;              % Tolerance RAT - Rational fraction approximation
% Definition of the field 
addOptional(info,'mass',default_mass,@isnumeric);
addOptional(info,'stiff',default_stiff,@(x) isnumeric(x)|| islogical(x));
addOptional(info,'CF',default_cf,@isscalar);
addOptional(info,'rat',default_rat,@(x)isnumeric(x)&&isscalar(x)&&(x>0));
parse(info,varargin{:}); % This additional info are in info.Results

%% ANALYSIS OF THE INPUTs

% SYSTEM MATRICES
if iscell(A)~=1,  error('The system matrices should be placed in a cell');
end
if iscell(dA)~=1, error('System matrices derivatives should be placed in a cell');
end

% Number of delays = Number of system matrices
if length(A)==length(tau),  h=length(tau);             
else, error('The delays vector dimension is not equal to the number of system matrices') 
end

% Cell-dimension
if size(A,1)~=1,   A=tranpose(A);
end
if size(dA,1)==h && size(dA,2)~=size(dA,1), dA=transpose(dA);
elseif size(dA,2)~=h,  error('System matrix derivatives are not all defined')
end
k=size(dA,1); K=ones(k,1);

% Dimension system matrices and their derivatives
for i=2:h                   
    if prod(size(A{1}(0,K))==size(A{i}(0,K)))~=1, error('The system matrices does not present the same dimension');
    end
    if size(A{i}(0,K),1)~=size(A{i}(0,K),2),      error('The system matrices are not square');
    end
    for ki=1:k
        if prod(size(dA{ki,1}(0,K))==size(dA{ki,i}(0,K)))~=1,    error('The system matrix derivatives does not present the same dimension');
        end
        if size(dA{ki,i}(0,K),1)~=size(dA{ki,i}(0,K),2),         error('The system matrix derivatives are not square');
        end    
    end
end

% Periodicity of system matrices
for i=1:h     
    if norm(A{i}(0,K)-A{i}(T,K),'fro')>1e-10,           warning('The %i-th system matrix does not seem periodic with period T, it is error is %1.5e', i, norm(A{i}(0,K)-A{i}(T,K)));
    end
    for ki=1:k
    if norm(dA{ki,i}(0,K)-dA{ki,i}(T,K),'fro')>1e-10,   warning('The %i-th system matrix derivative does not seem periodic with period T, it is error is %1.5e', i, norm(dA{ki,i}(0,K)-dA{ki,i}(T,K)));
    end
    end
end

% Positivity of the period 
if T<=0,    error('The period is not positive');    
end   

% DELAYs Positivity and minimal delay =0.
[~,ind]=sort(tau);          % Sorting the delays
if      tau(ind(1))<0,  error('The %i-th delay is not non-negative', i);    
elseif  tau(ind(1))>0,  warning('The minimal delay %3.2f is non-zero\n rewriting the system with minimal delay zero can speed up the solver and improve the accuracy',  tau(ind(1)));
end

%% CREATION OF THE SYSTEM STRUCTURE - PTDS
ptds=[];                        % PTDS
ptds.T=T;                       % PTDS: period
ptds.dim=length(A{1}(0,K));     % PTDS: system dimension
ptds.k=k;                       % PTDS: dimension of the controller parameter
ptds.tau=unique(tau(ind));      % PTDS: delays
ptds.h=length(ptds.tau);        % PTDS: number of delays
ptds.A=cell(1,ptds.h);          % PTDS: System Matrices
ptds.dA=cell(ptds.k,ptds.h);    % PTDS: System Matrices derivatives

% Re-arranging the system matrices w.r.t. the delays
s=1;  ptds.A{s}=A{ind(1)};
for ki=1:ptds.k,                 ptds.dA{ki,s}=dA{ki,ind(1)};
end
for i=2:h
    if tau(ind(i))==tau(ind(i-1)),   warning('The delay %3.2f is repeated, this can affect the efficiency of the solver.',  tau(ind(i)));
        ptds.A{s}=@(t,K) ptds.A{s}(t,K)+A{ind(i)}(t,K);
        for ki=1:ptds.k,    ptds.dA{ki,s}=@(t,K) ptds.dA{ki,s}(t,K)+dA{ki,ind(i)}(t,K);
        end
    else
        s=s+1;
        ptds.A{s}=A{ind(i)};
        for ki=1:ptds.k,  ptds.dA{ki,s}=dA{ki,ind(i)};
        end
    end
end 


nj=zeros(1,ptds.h);     % RATIONALITY DELAYS/PERIOD
dj=zeros(1,ptds.h);
for i=1:ptds.h
    if info.Results.rat==0,   [nj(i),dj(i)]=rat(ptds.tau(i)/T);
    else,                     [nj(i),dj(i)]=rat(ptds.tau(i)/T,info.Results.rat);
    end
end

Ncf=double(lcm(sym(dj)))*info.Results.CF;
N=double(lcm(sym(dj)));

nj=(nj./dj)*N;                      % delays in integer form 
njcf=(nj./dj)*Ncf;                  % delays in integer form 

ptds.N=N;                       % PTDS: Discretization of the interval [0,T]
ptds.Ncf=Ncf;                       % PTDS: Discretization of the interval [0,T]
ptds.nj=nj;                     % PTDS: Discretization of the interval [-tau_h,0]
ptds.njcf=njcf;                     % PTDS: Discretization of the interval [-tau_h,0]

indexes=zeros(N,ptds.h);   indexescf=zeros(N,ptds.h);
exponents=zeros(N,ptds.h); exponentscf=zeros(N,ptds.h);
for j=1:ptds.h
    for ell=0:N-1
        indexes(ell+1,j)  =mod(ell-nj(j),N)+1;
        indexescf(ell+1,j)=mod(ell-njcf(j),Ncf)+1;
        exponents(ell+1,j)  =floor((ell-nj(j))/N);
        exponentscf(ell+1,j)=floor((ell-njcf(j))/Ncf);
    end
    for ell=N:Ncf-1
        exponentscf(ell+1,j)=floor((ell-njcf(j))/Ncf);
        indexescf(ell+1,j)=mod(ell-njcf(j),Ncf)+1;
    end
end
ptds.ind  =indexes;               % PTDS: b_{n,j}
ptds.indcf=indexescf;               % PTDS: b_{n,j}
ptds.exp  =abs(exponents);        % PTDS: a_{n,j} 
ptds.expcf=abs(exponentscf);        % PTDS: a_{n,j} 

fprintf('\n  SYSTEM DIMENSIONS: \n');
fprintf('%i dimension of the system\n', ptds.dim);
if info.Results.CF==1
fprintf('%i minimal discretization of the interval [-tau_h,0]\n', nj(end));
fprintf('%i minimal discretization of the interval [0,T]\n',      N);
else
fprintf('%i discretization of the interval [-tau_h,0] (minimal discretization %i)\n',      njcf(end), nj(end));
fprintf('%i discretization of the interval [0,T]      (minimal discretization %i)\n',      Ncf,       N);
end
fprintf('SIMULATION: %ix%i=%i\n',  ptds.N, ptds.dim,  ptds.dim*ptds.N);
fprintf('DISCRETIZATION:        ''eig'' %ix(M+1) ''sol'' %ix(M+1) ''mon''         %ix(M+1)\n', ptds.dim*N*ptds.exp(1,end),    ptds.dim*(N+nj(end)),     ptds.dim*nj(end));
if info.Results.CF>1
fprintf('DISCRETIZATION sparse: ''eig'' %ix(M+1) ''sol'' %ix(M+1) ''mon''/''vpi'' %ix(M+1)\n', ptds.dim*Ncf*ptds.expcf(1,end),ptds.dim*(Ncf+njcf(end)), ptds.dim*njcf(end));
end
if ptds.dim==1 && ptds.N==1
  fprintf('The characteristic equation for the Floquet multiplier is available.\n\n');  
end

ptds.mass=info.Results.mass;

%% OPTIONS
options=[]; 
    options.print=1;  % Print the different values
    % options.addconj=0; % conjugate pair complex Floquet multipliers
    % BROYDEN'S OPTION:
    options.maxit=100;                    % Maximum number of Broyden's iteration
                                          % if 0 - whitout Broyden's iteration
    options.check_error_every=1;          % Check the error          
    options.damping=0.01;                 % Damping parameters
    options.tol=1e-7;                     % Desired tolerance of the algorithm 
    options.tol_conv=1e-12;               % Minimal convergence speed 
    options.Nvector=ones(1,ptds.N*ptds.dim); % Normalization vector
    
    % DIFFERENTIAL EQUATION SIMULATION
    options.stiff=info.Results.stiff;
    options.ode=1000;                 % Discretization point to simulate the NL operator eigenproblem
    options.safeguard=1000;           % Discretization point to simulate the NL operator eigenproblem in safeguard iteration
    % if 0 - automatic steplength with ode45 or ode15s
    options.RelTol=1e-5;    % ode45 - Relative tolerance 
    options.AbsTol=1e-7;    % ode45 - Absolute tolerance 
                              
if nargout==3
ptdsadj=ptds;
for i=1:h,       ptdsadj.A{i}=    @(t,K) transpose(ptds.A{i}(-t+tau(i),K));
end
ptdsadj.mass=transpose(ptds.mass);
ptdsadj.dA=[];
if N==1, R=1;
else, R=zeros(ptds.N); R(N:N-1:end-1)=1; 
end,    
if isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    R=kron(R,speye(ptds.dim));
else
    R=kron(R,ptdsadj.mass);
end
ptdsadj.R=sparse(R);


end

