% This script computes the largest in modulus Floquet multipliers varying
% the controller K.
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.
clc; close all; 
% LOADING THE FUNCTIONS
addpath(fileparts(pwd)) 

PDE=10; % DISCRETIZATION OF THE PDE
M=100;  CF=2;

%% SYSTEM DEFINITION
% Workpiece 
L=1;  % Length of workpiece
Ac=1; % Area of workpiece
ee=1; % Elasticity module   Kelvin-Voigt model
dd=1; % Damping Constant    Kelvin-Voigt model

% Milling Cutter - The blade
m=1;        % Mass
ap=1;       % axial depth of cut
KR=1;       % Radial component of the Force
KT=1;       % Transverse component of the Force

% Spring (where the blade is attached)
omega0=1;  % natural frequency
% K=zeta0  % (damping)ratio 

% Coupling force 
tau=1;       % Delay
T=1;         % Periodic function: theta(t)= 2*pi*t/tau;
thetae=pi; td=thetae*tau/(2*pi);
w=@(t) (mod(t,T)<=td).*ap.*(KR*sin(2*pi*t/tau).^2+KT*sin(4*pi*t/tau)/2); % t\in[0,td]


%% Discretization by the linear finite element basis 
delta=L/PDE; n1=ones(PDE,1);
D=(1/delta)*(spdiags([-n1 2*n1 -n1], -1:1, PDE, PDE)); D(end,end)=D(end,end)/2;
P=(delta/6)*(spdiags([n1 4*n1 n1],   -1:1, PDE, PDE)); P(end,end)=P(end,end)/2;

dim=(PDE+1)*2;              % System dimension
A=@(K) tau*[sparse(PDE+1,PDE+1),speye(PDE+1,PDE+1);...
           -ee*D, sparse(PDE,1), -dd*D, sparse(PDE,1);...
           sparse(1,PDE), -omega0^2, sparse(1,PDE), -2*omega0*K];
F=tau*[sparse(PDE*2,dim);...
    sparse(1,PDE-1), [1,1]/Ac,    sparse(1,PDE+1);...
    sparse(1,PDE-1), [1,1]/m,     sparse(1,PDE+1)];
% System matrices
A0=@(t,K) A(K)-F*w(t);
A1=@(t,K) F*w(t);
% Leading matrix
E=speye(dim); E(PDE+2:end-1,PDE+2:end-1)=P;
% Derivative System matrix
dA0=@(t,K) tau*[sparse(dim-1,dim);...
    sparse(1,dim-1), -2*omega0];
dA1=@(t,K) sparse(dim,dim);

%% PTDS CREATE
[ptds,options] = ptds_create({A0,A1},[0,tau],T,{dA0,dA1},'mass',E,'stiff',1,'CF',CF);
options.ode=1000;     options.safeguard=1000;
options.damping=0.1;  options.maxit=1000;

%% EVALUATION FOR DIFFERENT K
KK=linspace(0,1,500); algorithm='eig';
mu=zeros(3,length(KK));
for k=1:length(KK)
    [Mu] = eigsFloMU(ptds, M, KK(k),algorithm,4);
    [mu(1,k),~,out1,analysis] = cFloMU(ptds,KK(k),Mu(1),options);
    [mu(2,k),~,out2] = cFloMU(ptds,KK(k),Mu(2),options);
    [mu(3,k),~,out3] = cFloMU(ptds,KK(k),Mu(3),options);
    if out1+out2+out3~=0, error('ERROR')
    end
end

save('K_Varying','mu','KK','PDE','M','CF')
load('STB_Milling.mat')
plot(KK,abs(mu),'k'); hold on 
plot(iterates,sqrt(f),'*-')
axis([0,1,0.4,0.95])