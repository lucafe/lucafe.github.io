% This script performs the stabilization method on the milling model
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.
clc;clear; close all;
% LOADING THE FUNCTIONS
addpath(fileparts(pwd)) 

PDE=250; % DISCRETIZATION OF THE PDE
M=20; K0=0; CF=26;

%% SYSTEM DEFINITION
% Workpiece 
L=1;  % Length of workpiece
Ac=1; % Area of workpiece
ee=1; % Elasticity module   Kelvin-Voigt model
dd=1; % Damping Constant    Kelvin-Voigt model

% Milling Cutter - The blade
m=1;        % Mass
ap=1;       % axial depth of cut
KR=1;       % Radial component of the Force
KT=1;       % Transverse component of the Force

% Spring (where the blade is attached)
omega0=1;  % natural frequency
% K=zeta0  % (damping)ratio 

% Coupling force 
tau=1;       % Delay
T=1;         % Periodic function: theta(t)= 2*pi*t/tau;
thetae=pi; td=thetae*tau/(2*pi);
w=@(t) (mod(t,T)<td).*ap.*(KR*sin(2*pi*t/tau).^2+KT*sin(4*pi*t/tau)/2); % t\in[0,td]

%% Discretization by linear finite element basis 
delta=L/PDE; n1=ones(PDE,1);
D=(1/delta)*(spdiags([-n1 2*n1 -n1], -1:1, PDE, PDE)); D(end,end)=D(end,end)/2;
P=(delta/6)*(spdiags([n1 4*n1 n1],   -1:1, PDE, PDE)); P(end,end)=P(end,end)/2;

dim=(PDE+1)*2;              % System dimension
A=@(K) tau*[sparse(PDE+1,PDE+1),speye(PDE+1,PDE+1);...
           -ee*D, sparse(PDE,1), -dd*D, sparse(PDE,1);...
           sparse(1,PDE), -omega0^2, sparse(1,PDE), -2*omega0*K];
At=@(K) tau*[sparse(PDE,PDE+1),-ee*D, sparse(PDE,1);
             sparse(1,2*PDE+1),-omega0^2;
             speye(PDE,PDE),sparse(PDE,1), -dd*D, sparse(PDE,1);
             sparse(1,PDE), 1, sparse(1,PDE), -2*omega0*K];
F=tau*[sparse(PDE*2,dim);...
    sparse(1,PDE-1), [1,1]/Ac,    sparse(1,PDE+1);...
    sparse(1,PDE-1), [1,1]/m,     sparse(1,PDE+1)];
Ft=transpose(tau*[sparse(PDE*2,dim);...
    sparse(1,PDE-1), [1,1]/Ac,    sparse(1,PDE+1);...
    sparse(1,PDE-1), [1,1]/m,     sparse(1,PDE+1)]);
% System matrices
A0=@(t,K) A(K)-F*w(t);
A1=@(t,K) F*w(t);
% Leading Matrix
E=speye(dim); E(PDE+2:end-1,PDE+2:end-1)=P;
% Derivative system matrices
dA0=@(t,K) tau*[sparse(dim-1,dim);...
    sparse(1,dim-1), -2*omega0];
dA1=@(t,K) sparse(dim,dim);

%% PTDS CREATE
[ptds,options,ptdsadj] = ptds_create({A0,A1},[0,tau],T,{dA0,dA1},'mass',E,'stiff',1,'CF',CF);
ptdsadj.A={@(t,K) At(K)-Ft*w(-t),@(t,K) Ft*w(-t)};
ptdsadj.mass=E;
options.ode=100; options.tol=1e-6; options.maxit=300; % BROYDEN OPTIONS


%% OPTIMIZATION
[obj,opt] = optFloMU(ptds,M,options,ptdsadj); 
obj.algorithm='mon';
% HANSO OPTIONS
opt.prtlevel=2; opt.x0=K0; opt.maxit=1;  
% ARNOLDI OPTIONS
obj.algorithm='mon';
obj.opts.tol=1e-4; obj.opts.maxit=200; 
rng(0);
obj.opts.v0=rand(ptds.Ncf*dim*(M+1),1);

iterations=17; 
iterates=zeros(1,iterations); f=zeros(1,iterations); time=zeros(1,iterations);

iterates(1)=K0;
[mu,v] = eigsFloMU(ptds, M, K0,obj.algorithm,1,obj.opts);
        initial.H=eye(dim+1,dim+1); initial.v=v(1:dim);
[mu] = cFloMU(ptds,K0,mu,options,initial);
f(1)=abs(mu)^2;
timeHANSO=tic;
for k=2:iterations
    [iterates(k),f(k)] = hanso(obj, opt);     opt.x0=iterates(k); time(k)=toc(timeHANSO);
    save('STB_Milling.mat','iterates','f','time','PDE','M','CF');
end

