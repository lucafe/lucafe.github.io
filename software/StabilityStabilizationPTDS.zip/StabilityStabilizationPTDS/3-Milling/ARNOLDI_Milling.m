% This script analyzes the Arnoldi's method  convergence history  for the
% milling model in the designed controller parameter. 
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.
clear; close all;
% LOADING THE FUNCTIONS
addpath(fileparts(pwd)) 
 
PDE=250; % DISCRETIZATION OF THE PDE
M=20; CF=26;

load('MillingPDE250M20CF26.mat'); K=iterates(end);
%% SYSTEM DEFINITION
% Workpiece 
L=1;  % Length of workpiece
Ac=1; % Area of workpiece
ee=1; % Elasticity module   Kelvin-Voigt model
dd=1; % Damping Constant    Kelvin-Voigt model

% Milling Cutter - The blade
m=1;        % Mass
ap=1;       % axial depth of cut
KR=1;       % Radial component of the Force
KT=1;       % Transverse component of the Force

% Spring (where the blade is attached)
omega0=1;  % natural frequency
% K=zeta0  % (damping)ratio 

% Coupling force 
tau=1;       % Delay
T=1;         % Periodic function: theta(t)= 2*pi*t/tau;
thetae=pi; td=thetae*tau/(2*pi);
w=@(t) (mod(t,T)<=td).*ap.*(KR*sin(2*pi*t/tau).^2+KT*sin(4*pi*t/tau)/2); % t\in[0,td]

%% Discretization by linear finite element basis 
delta=L/PDE; n1=ones(PDE,1);
D=(1/delta)*(spdiags([-n1 2*n1 -n1], -1:1, PDE, PDE)); D(end,end)=D(end,end)/2;
P=(delta/6)*(spdiags([n1 4*n1 n1],   -1:1, PDE, PDE)); P(end,end)=P(end,end)/2;

dim=(PDE+1)*2;              % System dimension
A=@(K) tau*[sparse(PDE+1,PDE+1),speye(PDE+1,PDE+1);...
           -ee*D, sparse(PDE,1), -dd*D, sparse(PDE,1);...
           sparse(1,PDE), -omega0^2, sparse(1,PDE), -2*omega0*K];
At=@(K) tau*[sparse(PDE,PDE+1),-ee*D, sparse(PDE,1);
             sparse(1,2*PDE+1),-omega0^2;
             speye(PDE,PDE),sparse(PDE,1), -dd*D, sparse(PDE,1);
             sparse(1,PDE), 1, sparse(1,PDE), -2*omega0*K];

F=tau*[sparse(PDE*2,dim);...
    sparse(1,PDE-1), [1,1]/Ac,    sparse(1,PDE+1);...
    sparse(1,PDE-1), [1,1]/m,     sparse(1,PDE+1)];
Ft=transpose(tau*[sparse(PDE*2,dim);...
    sparse(1,PDE-1), [1,1]/Ac,    sparse(1,PDE+1);...
    sparse(1,PDE-1), [1,1]/m,     sparse(1,PDE+1)]);
% System matrices
A0=@(t,K) A(K)-F*w(t);
A1=@(t,K) F*w(t);
% Leading matrix
E=speye(dim); E(PDE+2:end-1,PDE+2:end-1)=P;
% Derivative system matrices
dA0=@(t,K) tau*[sparse(dim-1,dim);...
    sparse(1,dim-1), -2*omega0];
dA1=@(t,K) sparse(dim,dim);

%% PTDS CREATE
[ptds,options,ptdsadj] = ptds_create({A0,A1},[0,tau],T,{dA0,dA1},'mass',E,'stiff',1,'CF',CF);
options.ode=100; options.print=1;  options.tol=1e-8;
options.maxit=200;

rho=200;
obj.pairing=1e-6;
algorithm='vpi'; 
opts.tol=1e-4; opts.maxit=200;  
options.tol=1e-6;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DISCRETIZATION
[mu,V,analysis] = eigsFloMU(ptds, M, K,algorithm,rho,opts);

initial=[];
initial.H=speye(dim+1,dim+1); 

    initial.v=V(:,1);
    [mux,~,out] = cFloMU(ptds,K,mu(1),options,initial); 
    if out~=0,  error('Error at %f', KK(k));
    else, mu(1)=mux;
    end  
    initial.v=V(:,2);
    [mux,~,out] = cFloMU(ptds,K,mu(2),options,initial); 
    if out~=0,  error('Error at %f', KK(k));
    else, mu(2)=mux;
    end 
    initial.v=V(:,3);
    [mux,~,out] = cFloMU(ptds,K,mu(3),options,initial); 
    if out~=0,  error('Error at %f', KK(k));
    else, mu(3)=mux;
    end 

save('Kend_MillingPDE250M20CF26','mu','analysis','K')

%% CONVERGENCE HISTORY PLOT
pp=55;
for i=1:3
    semilogy(i:pp,analysis.error(i,i:pp)); hold on
end
for i=4:pp
    semilogy(i:pp,analysis.error(i,i:pp),'.k'); hold on
end
axis([1,pp,eps,10])

figure 
plot(real(mu(1:3)),imag(mu(1:3)),'*')
hold on, plot(abs(mu(1))*cos(0:0.1:2*pi), abs(mu(1))*sin(0:0.1:2*pi));

