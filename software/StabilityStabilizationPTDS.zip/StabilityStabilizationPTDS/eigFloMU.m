function [mu,q0,analysis] = eigFloMU(ptds, Mxi, K, algorithm)
%eigFloMU - Floquet MULTIPLIERS eigenvalue computation
% eigFloMU computes the Floquet multipliers by a spline collocation method
%   on a Chebyshev polynomial basis. 
%% INPUT
% ptds      - Structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% Mxi       - scalar: Polynomials degree - number of extrema Chebyshev nodes
%             vector: Collocation points in [-1,1] 
% K         - Control parameters
% eig       (optional) 
%           - 'eig' discretization of the non-linear eigproblem (default)
%           - 'sol' discretization of the solution
%           - 'mon' discretization of the monodromy operator
%% OUTPUT
% mu        - Floquet multipliers
% q0        - Right eigenvector of the non-linear eigenvalue problem
% analysis  - structure with additional information on the problem
%             (see below)
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

if nargout==3       % Inizialization of the structure analysis;
    analysis=[];
    % fields:
    % .nFM          - Number of non-phisical Floquet Multipliers
    % .spectrum     - Physical and non-phisical Floquet Multipliers
    % .rcond        - reciprocal condition number for eigenproblem
    % .size         - eigenproblem dimension
    %
    % algorithm='mon' do not present the field spectrum but it present the
    % field .V a matrix where every column represents the Chebyshev
    % coefficints of the eigenfunction of the monodromy operator
end

if isscalar(ptds.mass)==0 
    error('This software cannot handle the mass matrix, use eigsFloMU or divide system matrices by the mass matrix');
end

if isscalar(Mxi)==1                                    % Mxi = number of collocation points 
    M=Mxi;
    xi=(-cos((0:M-1)*pi/(M-1))); % extrema Chebyshev nodes 
elseif isvector(Mxi)*prod(abs(Mxi)<=1)*isreal(Mxi)==1  % Mxi = collocation points 
    if iscolumn(Mxi)==1,  xi=transpose(Mxi);
    else,                 xi=Mxi;
    end,                  M=length(Mxi);
else
    error('M must be a positive integer or a real vector with values in [-1,1]')
end

d=ptds.dim;              % System dimension
N=ptds.N;                % Number of subintervals in the time-period [0,T]
Delta=ptds.T/N;     dM=d*(M+1);  NdM=N*dM;   

%% CONSTRUCTION OF THE POLYNOMIAL BASIS
UU=zeros(M,M+1); % Polynomial basis for the derivative 
for i=2:M+1      % Chebishev polynomial of the 2nd kind evaluated in xi
    if i==2,     Ui=ones(size(xi));                  % degree 0
    elseif i==3, Ui=2*xi;  U1=Ui; U2=ones(size(xi)); % degree 1      
    else,        Ui=2*xi.*U1-U2; U2=U1; U1=Ui;       % degree i-2
    end
    UU(:,i)=2*(i-1)*Ui';
end
UU=[zeros(1,M+1);UU/Delta];       UU=kron(UU,eye(d));

TT=zeros(M,M+1); % Polynomial basis for the interpolating polynomial
for i=1:M+1      % Chebishev polynomial of the 1st kind evaluated in xi
    if i==1,     Ti=ones(size(xi));                   % degree 0
    elseif i==2, Ti=xi;  C1=xi; C2=ones(size(xi));    % degree 1       
    else,        Ti=2*xi.*C1-C2; C2=C1; C1=Ti;        % degree i-1
    end
    TT(:,i)=Ti';
end
TT=kron(TT,eye(d));

QQ0=kron((-1).^(0:M),eye(d)); QQ1=-kron(ones(1,M+1),eye(d)); 

%% EIG - DISCRETIZATION OF THE NON-LINEAR EIGENVALUE PROBLEM
if nargin==3 || prod(algorithm=='eig')==1 
   hbar=ptds.exp(1,end);  % Dimension of the eigenvalue problem NdM*hbar

   AAj=zeros(NdM,NdM,hbar+1);   
   Mexp=(hbar+1)-ptds.exp; Qind=ptds.ind;

   % POSITION THE DIFFERENTIAL EQUATION
   for n=1:N, ind=(n-1)*dM+1:n*dM; 
       for j=1:ptds.h,  AA=zeros(dM,dM);     % Block matrix 
           for i=1:M
              AA(i*d+1:(i+1)*d,:)= - ptds.A{j}((xi(i)/2+n-1/2)*ptds.T/N,K)...
                    *TT((i-1)*d+1:i*d,:);
           end
       AAj(ind,(Qind(n,j)-1)*dM+1:Qind(n,j)*dM,Mexp(n,j))=AA; % block position
       end
       AAj(ind,ind,Mexp(n,1))=AAj(ind,ind,Mexp(n,1))+UU; % position the derivative
   end

   % PERIODIC BOUNDARY CONDITION
   AAj(1:d,1:dM,end)=QQ0;               % mu*q_{1}(0)
   AAj(1:d,end-dM+1:end,end-1)= QQ1;  % q_{n}(1)
   for n=1:N-1   % continuity conditions
   AAj(n*dM+(1:d),(n-1)*dM+1:(n)*dM,end)=QQ1; %q_n(1)  
   AAj(n*dM+(1:d),(n)*dM+1:(n+1)*dM,end)=QQ0;  %q_{n+1}(0)
   end

   % LINEARIZATION OF THE POLYNOMIAL EIGENVALUE PROBLEM (open polyeig)             
   A = eye(NdM*hbar);      A(1:NdM,1:NdM) = AAj(:,:,1);
   B = zeros(NdM*hbar);    B((NdM+1):(NdM*hbar+1):end) = 1;
   for hi = 1:hbar,    ind = (hi-1)*NdM;
       B(1:NdM, ind+1:ind+NdM) = -AAj(:,:,hi+1); 
   end

    % NON-PHYSICAL FLOQUET MULTIPLIERS
    bc=d*(hbar*N-1);                     % boundary condition + continuity condition
    order=dM*sum(hbar-ptds.exp(:,end));  % non-maximal order differential equations
    delay=dM*sum(ptds.exp(:,1));         % non-zero minimal delay
    FMzeros=bc+order+delay;
   
    % Floquet Multipliers and their right eigenvector
    if nargout==1,  mu=eig(A,B); mu=sort(transpose(mu),'descend'); mu= mu(1:end-FMzeros);
       return;
    end
    [V,Mu]=eig(A,B,'vector');   [Mu,ind]=sort(transpose(Mu),'descend');
    
    if nargout==3  %% ANALYSIS
        analysis.nFM=FMzeros;                 analysis.spectrum=Mu;  
        analysis.rcond=[rcond(A);rcond(B)];   analysis.size=size(A);         
    end
    
    mu= Mu(1:end-FMzeros); V=V(1:NdM,ind(1:end-FMzeros)); q0=zeros(N*d,length(mu));
    for n=1:N,    q0((n-1)*d+1:n*d,:)=QQ0*V((n-1)*dM+1:n*dM,:);
    end
        
%% DISCRETIZATION OF THE SOLUTION & MONODROMY OPERATOR
else   
    nj=ptds.nj;   % Number of subintervals for [-\tau_j,0]
    nh=nj(end);   % Number of subintervals in the time-period [-tau_h,0]
    S=zeros(NdM,(N+nh)*dM); % System condition

    % POSITION THE DIFFERENTIAL EQUATION
    for n=1:N, row=(n-1)*dM+1:n*dM; col=(nh+n-1)*dM+1:(nh+n)*dM; 
        for j=1:ptds.h
        AA=zeros(dM,dM);     % Block matrix 
            for i=1:M
                AA(i*d+1:(i+1)*d,:)= - ptds.A{j}((xi(i)/2+n-1/2)*Delta,K)...
                    *TT((i-1)*d+1:i*d,:);
            end
        S(row,(nh+n-nj(j)-1)*dM+1:(nh+n-nj(j))*dM)=AA; % block position
        end
        S(row,col)=UU+S(row,col);                      % derivative position
    end

    for n=0:N-1   % positioning the continuity conditions
        S(n*dM+(1:d),(nh+n-1)*dM+1:(nh+n)*dM)=QQ1; %q_n(1)  
        S(n*dM+(1:d),(nh+n)*dM+1:(nh+n+1)*dM)=QQ0; %q_{n+1}(0)
    end

%% SOL - DISCRETIZATION of the SOLUTION
    if prod(algorithm=='sol')==1
        B=[S;eye(nh*dM),zeros(nh*dM,NdM)];
        A=[zeros(NdM,(nh+N)*dM);zeros(nh*dM,NdM),eye(nh*dM)];
        FMzeros=NdM; % Non-Physical Floquet multipliers
        
        % Floquet Multipliers and the right eigenvector
        if nargout==1,  mu=eig(A,B); mu=sort(transpose(mu),'descend'); mu= mu(1:end-FMzeros);
            return;
        end
        [V,Mu] = eig(A,B,'vector'); [Mu,ind]=sort(transpose(Mu),'descend');
    
        if nargout==3  %% ANALYSIS
            analysis.nFM=FMzeros;               analysis.spectrum=Mu;  
            analysis.rcond=[rcond(A);rcond(B)]; analysis.size=size(A);        
        end
        
        mu=Mu(1:end-FMzeros); V=V(end-NdM+1:end,ind(1:end-FMzeros)); q0=zeros(N*d,length(mu)); 
        for n=1:N,  q0((n-1)*d+1:n*d,:)=QQ0*V((n-1)*dM+1:n*dM,:);
        end

%% MON - DISCRETIZATION of the Monodromy operator   
    elseif prod(algorithm=='mon')==1 
        E=[zeros(nh*dM,NdM),eye(nh*dM)];
        Um=E*([S;eye(nh*dM),zeros(nh*dM,NdM)]\transpose(E));
               
        % Floquet Multipliers and the right eigenvector
        if nargout==1,  mu=eig(Um); mu=sort(transpose(mu),'descend'); 
            return;
        end
        [V,Mu] = eig(Um,'vector'); [mu,ind]=sort(transpose(Mu),'descend'); V=V(:,ind);
        
        q0=zeros(d*ptds.N, length(mu));
        s=nj(end);
        for n=N:-1:1,q0((n-1)*d+1:n*d,:)=QQ0*V((s-1)*dM+1:s*dM,:).*mu;
            if s>1, s=s-1;
            else, break
            end
        end
        if ptds.T>ptds.tau(end)
           q0(1:d,:)=-QQ1*V(end-dM+1:end,:); 
           if ptds.T>ptds.tau(end)+Delta % SIMULATION Periotic TDS 
              warning('The 10-dominant eigenvector are partially computed by dde23');
              sim=min(length(mu),10); q0=q0(:,1:sim);
              lags=ptds.tau(ptds.tau>0); opt = ddeset('RelTol',1e-6);
              tspan=0:Delta:(ptds.T-ptds.tau(end)-Delta);
              for i=1:sim
                  sol = dde23(@(t,y,Z) ddeptds(t,y,Z,ptds,K), lags, @(t) history(t,V(:,i),ptds.nj,Delta,d,M), tspan,opt);
                  sol=deval(sol,tspan);
                  for j=2:length(tspan)
                      q0((j-1)*d+1:j*d,i)=sol(:,j);
                  end
              end                
           end
        end
        
        if nargout==3  %% ANALYSIS
            analysis.rcond=rcond(Um); 
            analysis.size=size(Um);    
            analysis.V=V(:,ind);  
        end
    else, error('algorithm can be only one of the follwing strings: eig, sol or mon')
    end
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       ADDITIONAL FUNCTIONS 
%       for the computation of the right eigenvector with algorithm='mon'
%       by dde23 simulation
%       1-history: initial function of the periodic dde system
%       2-ddeptds: periodic dde system
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% HISTORY: computes the initial function of the periodic dde system by
%          Chebyshev coefficients v
function [y] = history(t,v,nj,Delta,d,M)
n=floor(t/Delta); xi=(t/Delta-n)*2-1;
n=n+nj(end);
if n==nj(end),    n=nj(end)-1; xi=1;
end
c=v(n*d*(M+1)+1:(n+1)*d*(M+1));
y=zeros(d,1);
for i=1:M+1, ind=(i-1)*d+1:i*d;    % Chebishev polynomial of the 1st kind evaluated in xi
    if i==1,     Ti=1;                                % degree 0
    elseif i==2, Ti=xi;  C1=xi; C2=1;                 % degree 1       
    else,        Ti=2*xi.*C1-C2; C2=C1; C1=Ti;        % degree i-1
    end
    y=y+c(ind)*Ti;
end    
end

% DDEPTDS: Periodic Time Delay System 
function dydt = ddeptds(t,y,Z,ptds,K)
dydt=zeros(size(y));z=0;
for i=1:ptds.h
    if ptds.tau(i)==0,   dydt=ptds.A{i}(t,K)*y+dydt;         z=z+1;
    else,                dydt=ptds.A{i}(t,K)*Z(:,i-z)+dydt;
    end
end
end
        