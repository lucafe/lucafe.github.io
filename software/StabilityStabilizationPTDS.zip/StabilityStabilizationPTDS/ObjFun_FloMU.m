function [f,df] = ObjFun_FloMU(K,obj)
%ObjFun_FloMU - Objective Function for stability optimitization with HANSO
%   This function describes the objective function for the minimization of
%   the largest in modulus Floquet multipliers by HANSO
%   See optFloMu for further information
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

%% DISCRETIZATION
[mu,V] = eigFloMU(obj.ptds,obj.M,K); % SPECTRAL DISCRETIZATION

%% BROYDEN's CORRECTIONS
if obj.options.maxit==0             
    mu=mu(1); v=V(:,1);
else                                % BROYDEN's CORRECTIONS
    mua=mu; out=2; k=0;
    if obj.initial==0       % safeguard initialization
        while out>0, k=k+1;
            if mua(k)<1e-15,  mu=mua(1); v=V(:,1); break
            end
            [mu,v,out] = cFloMU(obj.ptds,K,mua(k),obj.options); 
        end
    else                    % initialized on V
        initial.H=eye(obj.ptds.N*obj.ptds.dim+1);
        while out>0, k=k+1;     initial.v=V(:,k); 
           if mua(k)<1e-15,  mu=mua(1); v=V(:,1); break
           end
           [mu,v,out] = cFloMU(obj.ptds,K,mua(k),obj.options,initial); 
        end
    end
end

%% DERIVATIVE FLOQUET MULTIPLIER
[demu] = deFloMU(obj.ptds,K,mu,obj.options,v); 
%% OBJECTIVE FUNCTION and ITS DERIVATIVE
f=abs(mu)^2;
df=2*real(conj(mu)*demu);
end

