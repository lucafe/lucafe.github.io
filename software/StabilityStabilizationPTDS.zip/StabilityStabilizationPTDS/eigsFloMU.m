function [mu,q0,analysis] = eigsFloMU(ptds, Mxi, K, algorithm, rho,  opts)
%eigsFloMU - Floquet MULTIPLIERS eigenvalue computation - sparse solver
% eigFloMU computes the Floquet multipliers by a spline collocation method
%   on a Chebyshev polynomial basis. The eigenvalue computation is achieved
%   by Arnoldi's method.
%% INPUT
% ptds      - Structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% Mxi       - scalar: Polynomials degree - number of extrema Chebyshev nodes
%             vector: Collocation points in [-1,1] 
% K         - Control parameters
% eig       (optional) 
%           - 'eig' discretization of the non-linear eigproblem (default)
%           - 'sol' discretization of the solution
%           - 'mon' discretization of the monodromy operator
%           - 'vpi' very plain implementation of Arnodi method of 'mon'
% rho       (optional) number of largest magnitude eigenvalues returned (1)
% opts      (optional) Structure with additional parameters for Arnoldi
%              .maxit maximum number of iteration (300)
%              .tol   tolerance                   (1e-8)
%% OUTPUT
% mu        - Floquet multipliers
% q0        - Right eigenvector of the non-linear eigenvalue problem
% analysis  - structure with additional information on the problem
%             (see below)
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

% OPTIONAL INFORMATION
if nargin<5,      rho=1;   opts.tol=1e-6; opts.maxit=300;   
elseif nargin<6,           opts.tol=1e-6; opts.maxit=300;     
end

if nargout==3       % Inizialization of the structure analysis;
    analysis=[];
    % fields:
    % .size         - eigenproblem dimension                  (for all algorithm)
    % .condest      - lower bound for 1-norm condition number ('eig','sol')
    % .iter         - iteration Arnoldi                       ('vpi')
    % .residual     - residuals                               ('vpi')
    % .H            - Hessenberg                              ('vpi')
    % .O            - Orthogonal matrix                       ('vpi')
    % .spectrum     - Eigenvalues of the Hessenberg matrix    ('vpi')
end

if isscalar(ptds.mass)==1,    ptds.mass=speye(ptds.dim);
end

if isscalar(Mxi)==1                                    % Mxi = number of collocation points 
    M=Mxi;
    xi=(-cos((0:M-1)*pi/(M-1))); % extrema Chebyshev nodes 
elseif isvector(Mxi)*prod(abs(Mxi)<=1)*isreal(Mxi)==1  % Mxi = collocation points 
    if iscolumn(Mxi)==1,  xi=transpose(Mxi);
    else,                 xi=Mxi;
    end,                  M=length(Mxi);
else
    error('M must be a positive integer or a real vector with values in [-1,1]')
end

d=ptds.dim;              % System dimension
N=ptds.Ncf;              % Number of subintervals in the time-period [0,T]
Delta=ptds.T/N;     dM=d*(M+1);  NdM=N*dM;   

%% CONSTRUCTION OF THE POLYNOMIAL BASIS
UU=zeros(M,M+1); % Polynomial basis for the derivative 
for i=2:M+1      % Chebishev polynomial of the 2nd kind evaluated in xi
    if i==2,     Ui=ones(size(xi));                  % degree 0
    elseif i==3, Ui=2*xi;  U1=Ui; U2=ones(size(xi)); % degree 1      
    else,        Ui=2*xi.*U1-U2; U2=U1; U1=Ui;       % degree i-2
    end
    UU(:,i)=2*(i-1)*Ui';
end
UU=kron([zeros(1,M+1);UU/Delta],ptds.mass);

%UU=[zeros(1,M+1);UU/Delta];       UU=kron(UU,eye(d));

TT=zeros(M,M+1); % Polynomial basis for the interpolating polynomial
for i=1:M+1      % Chebishev polynomial of the 1st kind evaluated in xi
    if i==1,     Ti=ones(size(xi));                   % degree 0
    elseif i==2, Ti=xi;  C1=xi; C2=ones(size(xi));    % degree 1       
    else,        Ti=2*xi.*C1-C2; C2=C1; C1=Ti;        % degree i-1
    end
    TT(:,i)=Ti';
end
TT=kron(TT,eye(d));

QQ0=kron((-1).^(0:M),eye(d)); QQ1=-kron(ones(1,M+1),eye(d)); 

%% EIG - DISCRETIZATION OF THE NON-LINEAR EIGENVALUE PROBLEM
if nargin==3 || prod(algorithm=='eig')==1 
   hbar=ptds.expcf(1,end);  % Dimension of the eigenvalue problem NdM*hbar

   %AAj=zeros(NdM,NdM,hbar+1);  
   AAj=cell(1,hbar+1);
   for j=1:hbar+1,       AAj{j}=sparse(NdM,NdM);
   end
   Mexp=(hbar+1)-ptds.expcf; Qind=ptds.indcf;

   % POSITION THE DIFFERENTIAL EQUATION
   for n=1:N, ind=(n-1)*dM+1:n*dM; 
       for j=1:ptds.h,  AA=zeros(dM,dM);     % Block matrix 
           for i=1:M
              AA(i*d+1:(i+1)*d,:)= - ptds.A{j}((xi(i)/2+n-1/2)*ptds.T/N,K)...
                    *TT((i-1)*d+1:i*d,:);
           end
       AAj{Mexp(n,j)}(ind,(Qind(n,j)-1)*dM+1:Qind(n,j)*dM)=AA; % block position
       end
       AAj{Mexp(n,1)}(ind,ind)=AAj{Mexp(n,1)}(ind,ind)+UU; % position the derivative
   end

   % PERIODIC BOUNDARY CONDITION
   AAj{hbar+1}(1:d,1:dM)=QQ0;               % mu*q_{1}(0)
   AAj{hbar}(1:d,end-dM+1:end)= QQ1;  % q_{n}(1)
   for n=1:N-1   % continuity conditions
   AAj{hbar+1}(n*dM+(1:d),(n-1)*dM+1:(n)*dM)=QQ1; %q_n(1)  
   AAj{hbar+1}(n*dM+(1:d),(n)*dM+1:(n+1)*dM)=QQ0;  %q_{n+1}(0)
   end

   % LINEARIZATION OF THE POLYNOMIAL EIGENVALUE PROBLEM (open polyeig)             
   A = speye(NdM*hbar,NdM*hbar);     A(1:NdM,1:NdM) = sparse(AAj{1});
   B = sparse(NdM*hbar,NdM*hbar);    B((NdM+1):(NdM*hbar+1):end) = 1;
   for hi = 1:hbar,    ind = (hi-1)*NdM;
       B(1:NdM, ind+1:ind+NdM) = sparse(-AAj{hi+1}); 
   end
 
    % Floquet Multipliers and their right eigenvector
    if nargout==1,  mu=eigs(A,B,rho,'lm',opts); 
       return;
    end
     [v,mu] = eigs(A,B, rho,'lm',opts); mu=transpose(diag(mu));
    
    if nargout==3  %% ANALYSIS
        analysis.condest=[condest(A);condest(B)];   analysis.size=size(A);         
    end
    
    v=v(1:NdM,:); q0=zeros(N*d,length(mu));
    for n=1:N,    q0((n-1)*d+1:n*d,:)=QQ0*v((n-1)*dM+1:n*dM,:);
    end
        
%% DISCRETIZATION OF THE SOLUTION & MONODROMY OPERATOR
else   
    nj=ptds.njcf;   % Number of subintervals for [-\tau_j,0]
    nh=nj(end);   % Number of subintervals in the time-period [-tau_h,0]
    % POSITION THE DIFFERENTIAL EQUATION    
    S=[sparse(NdM,nh*dM),kron(speye(N,N),UU)]; % System condition
    if nj(1)==0,    j1=2;
       for n=1:N,       col=(nh+n-1)*dM+1:(nh+n)*dM; 
           for i=1:M,   row=((n-1)*dM+i*d+1): ((n-1)*dM+(i+1)*d);
               S(row,col)=S(row,col) - ptds.A{1}((xi(i)/2+n-1/2)*Delta,K)...
                    *TT((i-1)*d+1:i*d,:); 
           end
       end
    else,           j1=1; 
    end
    for j=j1:ptds.h
        for n=1:N,      col=(nh+n-nj(j)-1)*dM+1:(nh+n-nj(j))*dM; 
           for i=1:M,   row=((n-1)*dM+i*d+1): ((n-1)*dM+(i+1)*d);
               S(row,col)=- ptds.A{j}((xi(i)/2+n-1/2)*Delta,K)...
                    *TT((i-1)*d+1:i*d,:); 
           end
        end
    end

    for n=0:N-1   % positioning the continuity conditions
        S(n*dM+(1:d),(nh+n-1)*dM+1:(nh+n)*dM)=QQ1; %q_n(1)  
        S(n*dM+(1:d),(nh+n)*dM+1:(nh+n+1)*dM)=QQ0; %q_{n+1}(0)
    end

%% SOL - DISCRETIZATION of the SOLUTION
    if prod(algorithm=='sol')==1
        B=[S;speye(nh*dM),sparse(nh*dM,NdM)];
        A=[sparse(NdM,(nh+N)*dM);sparse(nh*dM,NdM),speye(nh*dM)];
        clearvars S;
        % Floquet Multipliers and the right eigenvector
        if nargout==1,  mu=eigs(A,B, rho,'lm',opts);     return;
        end
        [v,mu] = eigs(A,B, rho,'lm',opts); mu=transpose(diag(mu));
    
        if nargout==3  %% ANALYSIS
            analysis.condest=[condest(A);condest(B)]; analysis.size=size(A);        
        end
        v=v(end-NdM+1:end,:); q0=zeros(N*d,length(mu)); 
        for n=1:N,  q0((n-1)*d+1:n*d,:)=QQ0*v((n-1)*dM+1:n*dM,:);
        end

%% MON - DISCRETIZATION of the Monodromy operator   
    elseif prod(algorithm=='mon')==1 || prod(algorithm=='vpi')==1
        Sphi=S(:,1:end-NdM);       
        [L,U,P,Q]=lu(S(:,end-NdM+1:end));         
        clearvars S
    if prod(algorithm=='mon')==1 %% EIGS
        if nargout==1, mu= eigs(@(x) MONfun(x,Sphi,Q,U,L,P), ptds.njcf(end)*d*(M+1),rho,'lm',opts);     return;
        end
        [v,mu] = eigs(@(x) MONfun(x,Sphi,Q,U,L,P), ptds.njcf(end)*d*(M+1),rho,'lm',opts); 
        mu=transpose(diag(mu));
        if rho>length(mu), rho=length(mu); end
        
    else                         %% IMPLICIT RESTARTED ARNOLDI's METHOD
      n=nh*ptds.dim*(M+1);
      z=rand(n,1);                            % starting vector
      O=zeros(n,opts.maxit+1);                % orthogonal matrix
      H=zeros(opts.maxit+1,opts.maxit);       % Hessenberg matrix
      err=NaN(rho,opts.maxit);
      
      O(:,1)=z/norm(z);
      for j=1:opts.maxit
          z=MONfun(O(:,j),Sphi,Q,U,L,P);
          for i=1:j                        % ORTHOGONALIZATION 
              H(i,j)=O(:,i)'*z;        z=z-H(i,j)*O(:,i);
          end
          for i=1:j                         % RE-ORTHOGONALIZATION
             Htilde=O(:,i)'*z;
             z = z - Htilde*O(:,i);    H(i,j)=H(i,j)+Htilde;
          end
          H(j+1,j)=norm(z);           O(:,j+1) = z/norm(z);
          if H(j+1,j)<10*eps,  break;   end % LUCKY BREAKDOWN
             % the starting vector is a linear combination of O(:,1:j).
          [s,lambda]=eig(H(1:j,1:j),'vector'); 
          [lambda,ind]=sort(lambda,'descend');
          for i=1:min(rho,j)
              err(i,j)=abs(H(j+1,j)*s(j,ind(i))/lambda(i));
          end
          if max(err(:,j))<opts.tol, break, end % CONVERGENCE REACHED
      end
      
      if rho>j, warning('Computed eigenvalues %i',j); rho=j; end
      if nargout==1,  mu=transpose(lambda(1:rho));    return, 
      end
       mu=transpose(lambda(1:rho));    v=O(:,1:j)*s(:,ind(1:rho));
      
      if nargout==3
          analysis.iter=j;
          analysis.residual=diag(H(1:j+1,1:j),-1);
          analysis.H=H(1:j+1,j);
          analysis.O=O(:,j+1);
          analysis.error=err(:,1:j);
      end    
    end

    % EIGENVECTOR CONSTRUCTION
    q0=zeros(d*ptds.Ncf, length(mu));
    s=nj(end);
    for n=N:-1:1, q0((n-1)*d+1:n*d,:)=QQ0*v((s-1)*dM+1:s*dM,:).*mu;
        if s>1, s=s-1;
        else, break
        end
    end
    if ptds.T>ptds.tau(end), q0(1:d,:)=-QQ1*v(end-dM+1:end,:); 
       if ptds.T>ptds.tau(end)+Delta % SIMULATION Periotic TDS 
          warning('The dominant eigenvectors are partially computed by dde23');
          lags=ptds.tau(ptds.tau>0); tspan=0:Delta:(ptds.T-ptds.tau(end)-Delta); opt = ddeset('RelTol',1e-6);
            for i=1:rho
            sol = dde23(@(t,y,Z) ddeptds(t,y,Z,ptds,K), lags, @(t) history(t,v(:,i),ptds.njcf,Delta,d,M), tspan,opt);
            sol=deval(sol,tspan);
            for j=2:length(tspan),   q0((j-1)*d+1:j*d,i)=sol(:,j);
            end
            end                
        end
    end
        
    if nargout==3,  analysis.size=nh*ptds.dim*(M+1);    %% ANALYSIS
    end
    else, error('algorithm can be only one of the follwing strings: eig, sol, mon, vpi')
    end
end

if ptds.N~=ptds.Ncf, cf=ptds.Ncf/ptds.N;  ind=zeros(1,ptds.N*d);
    for n=1:ptds.N
        ind((n-1)*d+1:n*d)=(cf*(n-1)*d+1):(cf*(n-1)*d+d);
    end
    q0=q0(ind,:);
end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       ADDITIONAL FUNCTIONS 
%       for the computation of the right eigenvector with algorithm='mon'
%       by dde23 simulation
%       1-history: initial function of the periodic dde system
%       2-ddeptds: periodic dde system
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x] = MONfun(x,Sphi,Q,U,L,P)
    y=[x;Q*(U\(L\(P*(-Sphi*x))))];
    x=y(end-length(x)+1:end);
end


% HISTORY: computes the initial function of the periodic dde system by
%          Chebyshev coefficients v
function [y] = history(t,v,nj,Delta,d,M)
n=floor(t/Delta); xi=(t/Delta-n)*2-1;
n=n+nj(end);
if n==nj(end),    n=nj(end)-1; xi=1;
end
c=v(n*d*(M+1)+1:(n+1)*d*(M+1));
y=zeros(d,1);
for i=1:M+1, ind=(i-1)*d+1:i*d;    % Chebishev polynomial of the 1st kind evaluated in xi
    if i==1,     Ti=1;                                % degree 0
    elseif i==2, Ti=xi;  C1=xi; C2=1;                 % degree 1       
    else,        Ti=2*xi.*C1-C2; C2=C1; C1=Ti;        % degree i-1
    end
    y=y+c(ind)*Ti;
end    
end

% DDEPTDS: Periodic Time Delay System 
function dydt = ddeptds(t,y,Z,ptds,K)
dydt=zeros(size(y));z=0;
for i=1:ptds.h
    if ptds.tau(i)==0,   dydt=(ptds.mass\ptds.A{i}(t,K))*y+dydt;         z=z+1;
    else,                dydt=(ptds.mass\ptds.A{i}(t,K))*Z(:,i-z)+dydt;
    end
end
end
        