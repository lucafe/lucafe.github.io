function [NLeig,De_mu] = FloMU_scalar(ptds,K)
%FloMU_scalar -  Characteristic matrix equation for scalar system
% For a periodic time delay systems where the delays are natural multiples
% of the period, FloMU_scalar computes the characteristic matrix NLeig, and
% the derivative 
%% INPUT
% ptds      - Structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% K         - Controller
%% OUTPUT
% NLeig     - Function handle @(mu), describing the characteristic equation
% De_mu     - Function handle $(mu), computes the derivates of the Floquet
%             multiplier mu with respect to the controller parameters K
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

if ptds.dim>1 || ptds.N>1
    error('The periodic time delay system must be scalar and present commensurate delays')
end


hbar=ptds.exp(1,end);
Mexp=(ptds.exp(1,end)+1)-ptds.exp; 

syms s
aj=zeros(1,hbar+1);
    for j=1:ptds.h
        if isnumeric(ptds.A{j}(s,K))==1 % Autonomous matrix 
            aj(Mexp(j))=ptds.T*ptds.A{j}(s,K);
        else                          % Periodic Matrix
            aj(Mexp(j))=double(int(ptds.A{j}(s,K),0,ptds.T));
        end
    end

NLeig=@(mu) exp(aj*transpose(mu.^((-hbar:0))))-mu;


if nargout==2
   Denominator=@(mu) 1-aj(1:end-1)*transpose((-hbar:-1).*mu.^((-hbar):-1)); 
    De_mu=cell(length(K),1);
    for k=1:length(K)
        daj=zeros(1,hbar+1);
        for j=1:ptds.h
            if isnumeric(ptds.dA{k,j}(s,K))==1 % Autonomous matrix 
                daj(Mexp(j))=ptds.T*ptds.dA{k,j}(s,K);
            else                               % Periodic Matrix
                daj(Mexp(j))=double(int(ptds.dA{k,j}(s,K),0,ptds.T));
            end
        end
        De_mu{k}=@(mu) (daj*transpose(mu.^((1-hbar:1))))/Denominator(mu);
    end
end
end

