%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

clc;clear; close all;
% LOADING THE FUNCTIONS
addpath(fileparts(pwd)) 

%% SYSTEM DEFINITION
T=pi;                   % period
tau=[0,1,2]*T;          % delays

% System Matrices
A0=@(t,K) K*cos(2*t);
A1=@(t,K) sin(2*t)+K;
A2=@(t,K) 0.1*cos(2*t)*exp(sin(2*t));
A={A0,A1,A2};

% Derivatives system matrices:
dA0=@(t,K) cos(2*t);
dA1=@(t,K) 1;
dA2=@(t,K) 0;
dA={dA0,dA1, dA2};

%% CREATION of the SYSTEM
[ptds,options] = ptds_create(A,tau,T,dA);
K=exp(1)/pi;            % Controller parameters

%% DOMINANT FLOQUET MULTIPLIER and its DERIVATIVE
mu_exact=exp(1);                   % Dominant Floquet Multiplier
demu_exact=(pi/2);                 % Derivative w.r.t. K

%% Characteristic equation for ptds
[NLeig,De_mu] = FloMU_scalar(ptds,K); 
% NLeig(mu_exact)==0; % demu_exact==De_mu{1}(mu_exact);

%% ANALYSIS DISCRETIZATION
MM=2:100;                              % Discretization
mu_MM=zeros(size(MM));                 % Inizialization
for m=1:length(MM)
    [mu] = eigFloMU(ptds,MM(m),K);     mu_MM(m)=mu(1); 
end
loglog(MM,abs(mu_exact-mu_MM)/abs(mu_exact))
title('Spectral Discretization')

%% ANALYSIS NON-LINEAR EIGENVALUE PROBLEM
M=15;                                   % Discretization
ode=floor(10.^(1:0.05:4));              % step-sizes
options.tol=1e-15;  options.tol_conv=0; % Options for Broyden's

mu_ode=zeros(size(ode));  demu_ode=zeros(size(ode));    % corrected
for k=length(ode):-1:1,     options.ode=ode(k);         % step-size                         
    mu_ode(k) = cFloMU(ptds,K,mu_MM(M),options);        % correction
    demu_ode(k) = deFloMU(ptds,K,mu_ode(k),options);    % derivatives
end

figure 
loglog(1./ode,abs(mu_exact-mu_ode)/mu_exact), hold on
loglog(1./ode,abs(demu_exact-demu_ode)/demu_exact)
title('Accuracy of the algorithms')


%% STABILITY OPTIMIZATION
options.tol=1e-8;  options.tol_conv=0; options.ode=1000;
[obj,opt] = optFloMU(ptds,M,options); 
opt.prtlevel=2;   opt.x0=K; opt.maxit=1; 

iterations=5; iterates=zeros(1,iterations); f=zeros(1,iterations);

iterates(1)=K;
mua=eigFloMU(ptds,M,K); [muc,~,~,analysis] = cFloMU(ptds,K,mua(1),options);
f(1)=abs(muc)^2;
for k=2:iterations
    [iterates(k),f(k)] = hanso(obj, opt);     opt.x0=iterates(k);
end

%% OPTIMALITY CONDITION
a0=0; 
num=300; KK=linspace(-1.3,1,num);  mux=zeros(10,num);
for k=1:num, a1=KK(k)*pi;
        mux(1,k)=abs(a1/(lambertw(0,a1*exp(-a0))));
        mux(2,k)=abs(a1/(lambertw(1,a1*exp(-a0))));
        mux(3,k)=abs(a1/(lambertw(-1,a1*exp(-a0))));
        mux(4,k)=abs(a1/(lambertw(2,a1*exp(-a0))));
        mux(5,k)=abs(a1/(lambertw(-2,a1*exp(-a0))));
        mux(6,k)=abs(a1/(lambertw(3,a1*exp(-a0))));
        mux(7,k)=abs(a1/(lambertw(-3,a1*exp(-a0))));
        mux(8,k)=abs(a1/(lambertw(4,a1*exp(-a0))));
        mux(9,k)=abs(a1/(lambertw(-4,a1*exp(-a0))));
        mux(10,k)=abs(a1/(lambertw(5,a1*exp(-a0))));
end
[id]=find(isnan(mux(1,:))); mux(1,id)=exp(a0); % K(id)==0

% Exact value at the iterations
sqrtfex=zeros(size(iterates));
for k=1:iterations, a1=iterates(k)*pi;
   sqrtfex(k)=abs(a1/(lambertw(0,a1*exp(-a0))));
end

%% FIGURE STABILITY CONDITIONS
figure
semilogy(KK, abs(mux([1,2,3,4:2:end],:)),'-k'); hold on 
semilogy(iterates,sqrt(f),'*:')
title('Stability Optimization path')

%% SPECTRUM in the first iteration
mua_err=zeros(2,length(mua));
for k=1:length(mua),     mua_err(1,k)=abs(NLeig(mua(k)));
end

a1=K*T;
Nex=200; % Number of exact floquet multipliers
mue=zeros(1,Nex); mue_err=zeros(2,Nex);
for k=1:Nex, brunch=-floor(Nex/2-1)+k;
    mue(k)=a1/(lambertw(brunch,a1*exp(-a0)));
    mue_err(1,k)=abs(NLeig(mue(k)));
end

figure 
plot(real(mue),imag(mue),'*'), hold on
plot(real(mua),imag(mua),'o'); 
t=linspace(0,2*pi,150); plot(cos(t), sin(t))
title('Unstable Spectrum')

%% SPECTRUM - In the last iteration
[NLeig_opt] = FloMU_scalar(ptds,iterates(end)); 

[mua_opt] = eigFloMU(ptds,M,iterates(end));
for k=1:length(mua_opt),     mua_err(2,k)=abs(NLeig_opt(mua_opt(k)));
end
out=2; k=0;
while out>0, k=k+1;
   [muc_opt,~,out, analysis_opt] = cFloMU(ptds,iterates(end),mua_opt(k),options); 
end

a1=iterates(end)*T; 
mue_opt=zeros(1,Nex); err_e_opt=zeros(1,Nex);
for k=1:Nex, brunch=-floor(Nex/2-1)+k;
    mue_opt(k)=a1/(lambertw(brunch,a1*exp(-a0)));
    mue_err(2,k)=abs(NLeig_opt(mue_opt(k)));
end
figure 
plot(real(mue_opt),imag(mue_opt),'*'), hold on
plot(real(mua_opt),imag(mua_opt),'o'); 
plot(real(analysis_opt.guess),imag(analysis_opt.guess),'.-'); 
t=linspace(0,2*pi,150); plot(cos(t), sin(t))
title('Stable Spectrum')

%% SAVING
save('EX_scalar.mat','ptds','K','options','opt','mu_exact','demu_exact',...
                    'MM','mu_MM','ode','mu_ode','demu_ode',...
                    'iterates','f','sqrtfex','mux','KK',...
                    'mua','mue','mua_err','mue_err','analysis',...
                    'mua_opt','mue_opt','analysis_opt');
