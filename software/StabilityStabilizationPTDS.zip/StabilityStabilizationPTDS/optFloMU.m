function [obj,opt] = optFloMU(ptds,M,options,ptdsadj)
%optFloMU - Floquet Multipliers stability optimization
% optFloMU creates the input for the optimization handled by HANSO
%   Hybrid Algorithm for Non-Smooth Optimization
%   The objective function is the largest in modulus Floquet Multiplier
%% Input:    
% ptds    - Structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% M         - Number of discretization points
% K         - Control parameters
%
% Output:
% obj     - model for HANSO (is determined by the Inputs)
%           obj.ptds
%           obj.M
%           obj.options
% opt     - options for the optimization with HANSO
%           (see below for further information)
% 
% Option for HANSO:
% setting.normtol         - [Default: 1/M convergence rate of QMC]
%           Termination tolerance for smallest vector in 
%           convex hull of saved gradients
% setting.starting_vector - [Default: 10]
%           Number of starting point for the initialization of BFGS phase
% setting.x0              - [Default: randn]
%           Columns are one or more starting vector of variables, 
%           used to intialize the BFGS phase of the algorithm
% setting.maxit           - [Default: 500]
%           Max number of iterations for each BFGS starting point
% setting.samprad         - [Default: [10  1  0.1]*setting.evaldist]
%                           [] (no gradient sampling)
%           Sampling radii for gradient sampling
% setting.evaldist        - [Default: 1/sqrt(M) convergence rate of QMC]
%           Evaluation distance used to determine which gradients to use in
%           this computation  
%
% Option for the computation of the spectral abscissa
% setting.max_iter     - Maximum number of iteration used in the Newton's 
%               method to correct the approximation of the rightmost eigenvalue.
%               (DEFAULT: 10)
% setting.accuracy     - Stop criterion for Newton's method: norm on residual
%               (DEFAULT: 1e-14)
% setting.test         - The eigenvalues are computed if their modulo is less than
%               this value.
%               (DEFAULT: Inf)
% setting.verification - Verification test to check if the spectral
%               abscissa is coorectly evaluated 
%               0  - No verification test
%               1  - The maximum spectral abscissa of M samples is evaluated
%               2  - The maximum and the minimum spectral abscissa of M 
%                   samples is evaluated
%               (DEFAULT: 1)
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

%% MODEL FOR HANSO
obj=[];
obj.nvar=ptds.k;                % Number of controller parameters
if nargin==3
    obj.fgname='ObjFun_FloMU';            % function where ObjFun is defined
    obj.ptds=ptds;
    obj.initial=0;       % Initial function for the non-linear eigenproblem
        % 0 - right eigenvector and the matrix approximation are computed
        %     by safeguard iteration
        % 1 - right eigenvector is computed by spectral discretization
        %   - matrix approximation is the identity
    obj.algorithm='eig';
    
else
    obj.fgname='ObjFun_FloMU_Large';      % function where ObjFun is defined
    obj.ptds=ptds;
    obj.ptdsadj=ptdsadj;
    obj.pairing=1e-3;
    obj.rho=2*ptds.k+1;           % Number of dominant Floquet multipliers computed by Arnoldi's algorithm
    obj.algorithm='mon';
    obj.opts.tol=1e-6;            % Tolerance for ARNOLDI
    obj.opts.maxit=300;           % Maximum iterations for ARNOLDI
    obj.timing=1; 
end

options.print=0;         % The inner function will not show their result
obj.M=M;
obj.options=options;

      
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
%% Options for HANSO:
opt=[]; 
% normtol:   termination tolerance for smallest vector in convex hull of 
%            saved gradients
opt.normtol=1e-4;   % (default: 1e-4)

% x0:       columns are one or more starting vector of variables, 
%           used to intialize the BFGS phase of the algorithm
%           (default: 10 starting points are generated randomly)
starting_vector=10;            % number of starting vector
opt.x0 = randn(ptds.k, starting_vector);

% opt.maxit: max number of iterations for each BFGS starting point
opt.maxit=500;              % (default: 1000)

% options.evaldist: evaluation distance used to determine which
%          gradients to use in this computation 
opt.evaldist=1e-4;        % (default: 1e-4)


% samprad: sampling radii for gradient sampling
%           otherwise [] (no gradient sampling) 
opt.samprad=[]; 

% nvec:     0 for full BFGS matrix update in BFGS phase, otherwise 
%           number of vectors to save and use in the limited memory updates
%          (default: 0)

% fvalquit: quit if f drops below this value 
%          (default: -inf)

% cpumax:   quit if cpu time in seconds exceeds this
%          (default: inf)

% prtlevel: print level, 0 (no printing), 1, or 2 (verbose)
%          (default: 1)
end

