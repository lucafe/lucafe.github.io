%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.
clc;clear; close; rng(0)
% LOADING THE FUNCTIONS
addpath(fileparts(pwd)) 

%% SYSTEM DEFINITION
T=pi;                   % period
tau=[0,3/4]*pi;          % delays

delta=4; epsilon=2; 
% Controller
% K(1) - Integral
% K(2) - Proportional
% K(3) - Derivative

% System Matrices
A0=@(t,K) [0, 1, 0; 0, 0, 1; 0, -delta-epsilon*cos(2*t), 0];
A1=@(t,K) -[0,0,0;0,0,0;K(1),K(2),K(3)];
A={A0,A1};

% Derivatives system matrices
% w.r.t. K(1)
d1A0=@(t,K) zeros(3);
d1A1=@(t,K) [0,0,0;0, 0,0;-1,0,0];
% w.r.t. K(2)
d2A0=@(t,K) zeros(3);
d2A1=@(t,K) [0,0,0;0, 0,0;0,-1,0];
% w.r.t. K(3)
d3A0=@(t,K) [0,0,0;0, 0,0;0,0,0];
d3A1=@(t,K) [0,0,0;0, 0,0;0,0,-1];
dA={d1A0,d1A1; d2A0,d2A1; d3A0,d3A1};


%% CREATION of the SYSTEM
[ptds,options] = ptds_create(A,tau,T,dA);

%% STABILITY OPTIMIZATION
M=10;
options.ode=500;
[obj,opt] = optFloMU(ptds,M,options); 
opt.prtlevel=2;    opt.x0 = randn(ptds.k, 1); 

[Kpid,~] = hanso(obj, opt);    
% 2nd stability optimization with refined stepsize
opt.options.ode=1000;
opt.x0 = Kpid; 
[Kpid,fpid] = hanso(obj, opt);    

% 3rd stability optimization with refined stepsize
opt.options.ode=5000;
obj.M=30;
opt.x0 = Kpid; 
[Kpid,fpid] = hanso(obj, opt);  
save('Mathieu_PID','ptds','options','obj','opt','Kpid','fpid','M');
 
