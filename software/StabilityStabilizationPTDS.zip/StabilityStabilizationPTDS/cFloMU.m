function [mu,v,out,analysis] = cFloMU(ptds,K,mu,options,initial)
%cFloMU - Floquet MULTIPLIER Broyden's correction
% cFloMU correct the Floquet multiplier approximation mu by Broyden's
%  method on the non-linear eigenvalue problem. 
%% INPUT
% ptds      - structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% K         - Control parameters
% mu        - Floquet multiplier estimates
% options   - structure with multiple parameters for Broyden's method
%             (see ptds_create for further information information)
% initial   - structure with optional initialization parameters
%             .H  - approximation of the inverse jacobian  (Nd+1) x (Nd+1)
%             .v  - approximation of the right eigenvector Nd x 1
% (if initial is not specified then N and v are computed by a safeguard
% iteration)
%% OUTPUT
% mu        - corrected Floquet multipliers 
% v         - Right eigenvector of the non-linear eigenvalue problem
% out       - Output of the Broyden's method
%               0 - Found (mu,v) below tolerance
%               1 - Slow convergence of the iterates
%               2 - Iteration Exceeds
% analysis  - structure with additional information on the problem
%             (see below)
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.


c=options.Nvector;  % normalization vector

%% INITIALIZATION
if nargin==5    % INITIALIZATION with Hessian and eigenvector
   H=initial.H;
   v=initial.v;
   v=v/(c*v);                       % Normalization condition 
   rk=[NLeig(ptds,mu,v,K,options.ode,options); 0]; % Residual
else            % SAFEGUARD ITERATION
   No=eye(ptds.N*ptds.dim);  % Approximated Matrix operator on the canonical basis
   for k=1:ptds.N*ptds.dim
       No(:,k)=NLeig(ptds,mu,No(:,k),K,options.safeguard,options);
   end
   [VNo,DNo] = eig(No,'vector'); 
   [~,ind_d]=min(abs(DNo));
   v=VNo(:,ind_d); 
   v=v/(c*v);                % Normalization condition 
   rk=[DNo(ind_d)*v; 0];     % Residual No*v= DNo(ind_d)*v
   
   W=demuNLeig(ptds,mu,v,K,options.safeguard,options);    % Differentiation w.r.t. mu
   H=inv([No, W; c, 0]);                                  % Inverse of the approximated jacobian
end

% ANALYSIS STRUCTURE
if nargout==4       % Inizialization of the structure analysis;
   analysis=[]; 
   % fields:
   analysis.v1=v;    % approximated right eigenvector
   % .iter   - number of iteration required
   % .err    - error=2-norm residual/norm(right eigenvector)
   % .r      - 2-norm residual of the operator on the eigenpair
   guess=NaN(1,options.maxit);  % Guess of the Floquet multiplier
   rguess=NaN(1,options.maxit); % 2-norm residuals of guess 
   mnorm=NaN(1,options.maxit);  % norm of the matrix H
end

x=[v;mu];
s=0;        % SLACK VARIABLE for slow convergence
for j=1:options.maxit       
    if nargout==4, guess(j)=x(end);  rguess(j)=norm(rk(1:end-1)); mnorm(j)=norm(H,'fro'); 
    end
    
    dx=-H*rk;           % Newton-like update
  
    % Selection of the damping parameter [Jarlebring2018, Remark 3.3]
    gamma=min(1,options.damping/norm(dx));
    x=x+gamma*dx;       % dampaded update
    
    rk=[NLeig(ptds,x(end),x(1:end-1),K,options.ode,options); c*x(1:end-1)-1];    % New residual
   
    if mod(j,options.check_error_every)==0  % CHECK ERROR
       error=norm(rk); 
       if options.print==1    
       fprintf('%3i,   error=%e,   structure deviation=%e,   mu=%1.5f  %1.5fi;\n',...
       j,    error,     norm(c*v-1), real(x(end)),imag(x(end)));  
       end
       if error<options.tol, break                    % BELOW TOLERANCE
       end
       if norm(gamma*dx)<options.tol_conv, s=1; break % SLOW CONVERGENCE
       end
    end
    
    % rank-1 updates
    H=H-((H*rk+(1-gamma)*dx)*dx'*H)/(dx'*(H*rk+dx));
    
    if isnan(norm(H))==1, s=1; 
        error=norm(rk); %/norm(x(1:end-1)); 
        break
    end
end

%% ANALYSIS
if error<options.tol;           out=0;      % BELOW TOLERANCE
    if options.print==1
    fprintf('\n Below tolerance: %e, Floquet multiplier  %1.5f  %1.5fi\n\n',error, real(x(end)),imag(x(end)))
    end
elseif j<options.maxit && s==1, out=1;      % SLOW CONVERGENCE
    if options.print==1
    fprintf('\n SLOW CONVERGENCE: %e, Floquet multiplier  %1.5f  %1.5fi\n\n',error, real(x(end)),imag(x(end)))
    end
else,                           out=2;      % ITERATION EXCEEEDs
    if options.print==1
    fprintf('\n ITERATIONS EXCEED: %e, Floquet multiplier  %1.5f  %1.5fi\n\n',error, real(x(end)),imag(x(end)))
    end
end

mu=x(end);  v=x(1:end-1);

% SAVING THE RESULTS
if nargout==4
   analysis.iter=j;             % iteration - Broyden's method  
   analysis.err=error;          % error=norm(rk)/norm(v) -Broyden's method  
   analysis.r=norm(rk(1:end-1));         % 2-norm residuals
   analysis.guess=guess(1:j);   % Guess Floquet multipliers
   analysis.rguess=rguess(1:j); % 2-norm residual of the guess
   analysis.mnorm=mnorm(1:j);   % 2-norm T-matrix (inverse of No(mu))
end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                   ADDITIONAL FUNCTIONS
%                   1-Nonlinear eigenvalue problem
%                   2-Derivative w.r.t. mu
%                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1 - Non-linear eigenvalue problem
function [qq] = NLeig(ptds,mu,q0,K,ode,options)
d=ptds.dim; N=ptds.N;   % System Dimension

if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    if ode>0 %% Runge Kutta 4 (standalone implementation)
        M=ode; h=1/M; t=0; y=q0;
        for k=1:M
            s1=h*DiffEq(t)    *  y;
            s2=h*DiffEq(t+h/2)* (y+s1/2);
            s3=h*DiffEq(t+h/2)* (y+s2/2);
            s4=h*DiffEq(t+h)  * (y+s3);
            y=y+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
    else   %% ODE45  
        tspan=[0,1]; options_ode = odeset('RelTol',options.RelTol,'AbsTol',options.AbsTol);
        [~,q] = ode45(@(t,q) DiffEq(t)*q, tspan, q0,options_ode);
        y=transpose(q(end,:));
    end
else
     if sum(sum(ptds.mass==0))==1,     E=eye(ptds.N*d);
     else,                             E=ptds.mass;
     end

    if ode>0  %% TRAPEZOIDAL RULE (standalone implementation)
        M=ode; h=1/M; t=0;   A0=E+h*DiffEq(t)/2; y=q0;
        for k=1:M;    t=t+h; A1=E-h*DiffEq(t)/2; y=A1\(A0*y); A0=-A1+2*E;            
        end
    
    else     %% ODE15s (adaptive step size)
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq(t));
      [~,q] = ode15s(@(t,q) DiffEq(t)*q,[0,1],q0,options_ode);    
      y=transpose(q(end,:));
    end
end         
B=kron([zeros(N-1,1),eye(N-1);mu, zeros(1,N-1)],eye(d));
qq=y-B*q0;

%% SYSTEM DEFINTION (Nested Function)
    function Amu = DiffEq(t)
    Amu=zeros(d*N,d*N);  
    for ell=1:N,            row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h,     col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col)=Amu(row,col)+ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
        end
    end
    Amu=sparse((ptds.T/N)*Amu);
    end
end

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2 - DERIVATIVE w.r.t. mu 
function    qq_mu=demuNLeig(ptds,mu,v,K,ode,options)
d=ptds.dim; N=ptds.N;   % System Dimension
y0=[v;zeros(d*N,1)];
if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    if ode>0    %% Runge Kutta 4 (standalone implementation)
        M=ode; h=1/M; t=0; y=y0;
        for k=1:M
            s1=h*DiffEq_mu(t)    * y;
            s2=h*DiffEq_mu(t+h/2)*(y+s1/2);
            s3=h*DiffEq_mu(t+h/2)*(y+s2/2);
            s4=h*DiffEq_mu(t+h)  *(y+s3);
            y=y+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
        qq_mu=y((N*d+1):end);
    else   %% ODE45  
        tspan=[0,1]; options_ode = odeset('RelTol',1e-5,'AbsTol',1e-7, 'Jacobian',@(t,y) DiffEq_mu(t));
        [~,q] = ode45(@(t,q) DiffEq_mu(t)*q, tspan, y0,options_ode);
        qq_mu=transpose(q(end,(N*d+1):end));
    end
else
     if sum(sum(ptds.mass==0))==1,     E=kron(speye(2),speye(ptds.N*d));
     else,                             E=kron(speye(2),kron(speye(ptds.N),ptds.mass));
     end

    if ode>0   %% TRAPEZOIDAL RULE (standalone implementation)
        M=ode; h=1/M; t=0;   A0=E+h*DiffEq_mu(t)/2; y=y0;
        for k=1:M;    t=t+h; A1=E-h*DiffEq_mu(t)/2; y=A1\(A0*y); A0=-A1+2*E;            
        end, qq_mu=y((N*d+1):end);
    
    else     %% ODE15s (adaptive step size)
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq_mu(t));
      [~,q] = ode15s(@(t,q) DiffEq_mu(t)*q,[0,1],q0,options_ode);    
      qq_mu=transpose(q(end,(N*d+1):end));
    end
end
qq_mu((end-d+1):end)=qq_mu((end-d+1):end)-v(1:d);    
%% SYSTEM DEFINTION for the DERIVATIVE (NESTED FUNCTION)
    function Amu_mu = DiffEq_mu(t)
    Amu=zeros(d*N,d*N);  Amu1=Amu;
    for ell=1:N,            row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h,     col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col) =Amu(row,col) +ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
            Amu1(row,col)=Amu1(row,col)-ptds.exp(ell,j)*ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j)-1);
        end
    end
    Amu_mu=sparse((ptds.T/N)*[Amu,zeros(d*N,d*N);Amu1,Amu]);
    end
end 