function [demu] = deFloMU(ptds,K,mu,options,v,u)
%deFloMU - computate  Floquet Multiplier derivatives
% deFloMU computes the  partial derivatives of the Floquet multipliers mu
%   w.r.t. the controller parameters K.
%% INPUT
% ptds      - structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% K         - Control parameters
% mu        - Floquet multiplier 
% options   - structure with multiple parameters for Broyden's method
%             (see ptds_create for further information information)
% v         - (optional) right eigenvector associated to the Floquet multipliers 
% u         - (optional) left eigenvector associated to the Floquet multipliers 
% (if u & v are not specified then they are computed by a safeguard iteration)
%% OUTPUT
% demu      - derivatives of the Floquet multipliers w.r.t. K
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

%% INITIALIZATION
if nargin<6                  % SAFEGUARD ITERATION  
   No=eye(ptds.N*ptds.dim);  % Approximated Matrix operator on the canonical basis
   for k=1:ptds.N*ptds.dim
       No(:,k)=NLeig(ptds,mu,No(:,k),K,options);
   end
   [V,D,W] =eig(No,'vector'); 
   [sigma,ind_d]=min(abs(D));
   if nargin==4 || sigma<norm(NLeig(ptds,mu,v,K,options))
       v=V(:,ind_d);
   end
   u=W(:,ind_d); 
end



demu=zeros(ptds.k,1); % Inizialization Gradient
q_mu=demuNLeig(ptds,mu,v,K,options);
for ki=1:ptds.k
    q_K=deKNLeig(ptds,mu,v,K,ki,options); 
    demu(ki)=-(u'*q_K)/(u'*q_mu);     % Gradient
end


end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                   ADDITIONAL FUNCTIONS
%                   1-Nonlinear eigenvalue problem
%                   2-Derivative w.r.t. mu
%                   3-Derivative w.r.t. K(ki)
%                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1- Non-Linear EIGENVALUE PROBLEM
function [qq] = NLeig(ptds,mu,q0,K,options)
d=ptds.dim; N=ptds.N;   % System Dimension
if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    if options.ode>0 %% Runge Kutta 4 (standalone implementation)
        M=options.ode; h=1/M; t=0; y=q0;
        for k=1:M
            s1=h*DiffEq(t)    *y;
            s2=h*DiffEq(t+h/2)*(y+s1/2);
            s3=h*DiffEq(t+h/2)*(y+s2/2);
            s4=h*DiffEq(t+h)  *(y+s3);
            y=y+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
    else   %% ODE45  
        tspan=[0,1]; options_ode = odeset('RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq(t));
        [~,q] = ode45(@(t,q) DiffEq(t)*q, tspan, q0,options_ode);
        y=transpose(q(end,:));
    end
else
     if sum(sum(ptds.mass==0))==1,     E=speye(ptds.N*d);
     else,                             E=ptds.mass;
     end

    if options.ode>0  %% TRAPEZOIDAL RULE (standalone implementation)
        M=options.ode; h=1/M; t=0;   A0=E+h*DiffEq(t)/2; y=q0;
        for k=1:M;    t=t+h; A1=E-h*DiffEq(t)/2; y=A1\(A0*y); A0=-A1+2*E;            
        end
    
    else     %% ODE15s (adaptive step size)
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq(t));
      [~,q] = ode15s(@(t,q) DiffEq(t)*q,[0,1],q0,options_ode);    
      y=transpose(q(end,:));
    end
end         
B=kron([zeros(N-1,1),eye(N-1);mu, zeros(1,N-1)],eye(d));
qq=y-B*q0;
%% SYSTEM DEFINTION (Nested Function)
    function Amu = DiffEq(t)
    Amu=zeros(d*N,d*N);  
    for ell=1:N, row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h, col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col)=Amu(row,col)+ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
        end
    end
    Amu=sparse((ptds.T/N)*Amu);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2 - DERIVATIVE w.r.t. mu 
function    qq_mu=demuNLeig(ptds,mu,v,K,options)
d=ptds.dim; N=ptds.N;   % System Dimension
y0=[v;zeros(d*N,1)];
if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    if options.ode>0    %% Runge Kutta 4 (standalone implementation)
        M=options.ode; h=1/M; t=0; y=y0;
        for k=1:M
            s1=h*DiffEq_mu(t)*y;
            s2=h*DiffEq_mu(t+h/2)*(y+s1/2);
            s3=h*DiffEq_mu(t+h/2)*(y+s2/2);
            s4=h*DiffEq_mu(t+h)*(y+s3);
            y=y+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
        qq_mu=y((N*d+1):end);
    else   %% ODE45  
        tspan=[0,1]; options_ode = odeset('RelTol',1e-5,'AbsTol',1e-7, 'Jacobian',@(t,y) DiffEq_mu(t));
        [~,q] = ode45(@(t,q) DiffEq_mu(t)*q, tspan, y0,options_ode);
        qq_mu=transpose(q(end,(N*d+1):end));
    end
else
     if sum(sum(ptds.mass==0))==1,     E=kron(speye(2),speye(ptds.N*d));
     else,                             E=kron(speye(2),kron(speye(ptds.N),ptds.mass));
     end

    if options.ode>0  %% TRAPEZOIDAL RULE (standalone implementation)
        M=options.ode; h=1/M; t=0;   A0=E+h*DiffEq_mu(t)/2; y=y0;
        for k=1:M;    t=t+h; A1=E-h*DiffEq_mu(t)/2; y=A1\(A0*y); A0=-A1+2*E;            
        end, qq_mu=y((N*d+1):end);
    
    else     %% ODE15s (adaptive step size)
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq_mu(t));
      [~,q] = ode15s(@(t,q) DiffEq_mu(t)*q,[0,1],y0,options_ode);    
      qq_mu=transpose(q(end,(N*d+1):end));
    end
end
qq_mu((end-d+1):end)=qq_mu((end-d+1):end)-v(1:d); 
%% SYSTEM DEFINTION for the DERIVATIVE (NESTED FUNCTION)
    function Amu_mu = DiffEq_mu(t)
    Amu=zeros(d*N,d*N);  Amu1=Amu;
    for ell=1:N,            row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h,     col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col) =Amu(row,col) +ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
            Amu1(row,col)=Amu1(row,col)-ptds.exp(ell,j)*ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j)-1);
        end
    end
    Amu_mu=sparse((ptds.T/N)*[Amu,zeros(d*N,d*N);Amu1,Amu]);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3 - DERIVATIVE w.r.t. K(ki)
function    qq_mu=deKNLeig(ptds,mu,v,K,ki,options)
d=ptds.dim; N=ptds.N;   % System Dimension
y0=[v;zeros(d*N,1)];
if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    if options.ode>0    %% Runge Kutta 4 (standalone implementation)
        M=options.ode; h=1/M; t=0; y=y0;
        for k=1:M
            s1=h*DiffEq_K(t)*y;
            s2=h*DiffEq_K(t+h/2)*(y+s1/2);
            s3=h*DiffEq_K(t+h/2)*(y+s2/2);
            s4=h*DiffEq_K(t+h)*(y+s3);
            y=y+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
        qq_mu=y((N*d+1):end);
    else   %% ODE45  
        tspan=[0,1]; options_ode = odeset('RelTol',1e-5,'AbsTol',1e-7, 'Jacobian',@(t,y) DiffEq_K(t));
        [~,q] = ode45(@(t,q) DiffEq_K(t)*q, tspan, y0,options_ode);
        qq_mu=transpose(q(end,(N*d+1):end));
    end
else
     if sum(sum(ptds.mass==0))==1,     E=kron(speye(2),speye(ptds.N*d));
     else,                             E=kron(speye(2),kron(speye(ptds.N),ptds.mass));
     end

    if options.ode>0  %% TRAPEZOIDAL RULE (standalone implementation)
        M=options.ode; h=1/M; t=0;   A0=E+h*DiffEq_K(t)/2; y=y0;
        for k=1:M;    t=t+h; A1=E-h*DiffEq_K(t)/2; y=A1\(A0*y); A0=-A1+2*E;            
        end,qq_mu=y((N*d+1):end);
    
    else     %% ODE15s (adaptive step size)
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol, 'Jacobian',@(t,y) DiffEq_K(t));
      [~,q] = ode15s(@(t,q) DiffEq_K(t)*q,[0,1],y0,options_ode);    
      qq_mu=transpose(q(end,(N*d+1):end));
    end
end
%% SYSTEM DEFINTION for the DERIVATIVE (NESTED FUNCTION)
    function Amu_K = DiffEq_K(t)
    Amu=zeros(d*N,d*N);  Amu1=Amu;
    for ell=1:N,            row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h,     col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col) =Amu(row,col) +ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
            Amu1(row,col)=Amu1(row,col)+ptds.dA{ki,j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
        end
    end
    Amu_K=sparse((ptds.T/N)*[Amu,zeros(d*N,d*N);Amu1,Amu]);
    end
end

