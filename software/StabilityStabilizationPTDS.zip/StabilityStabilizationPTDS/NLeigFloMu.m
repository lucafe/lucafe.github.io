function [q1,tt,qq] = NLeigFloMu(ptds,mu,q0,K,options)
%NLeigFloMU - Non-Linear eigenvalue problem for the Floquet Multipliers
%   NLeigFloMU evaluates the action of the non-linear operator associated
%   to the Floquet multiplier mu on the vector q0. It computes also the
%   eigenfunction associated to the Floquet multipliers mu in the interval
%   [0,ptds.T]
%% INPUT
% ptds      - structure describing the periodic time delay system 
%             (see ptds_create for further information information)
% K         - Control parameters
% mu        - Floquet multiplier 
% q0        - vector for which we want to compute the action
% options   - structure with multiple parameters 
%             (see ptds_create for further information information)
%             field requested 
%             .ode or .RelTol .AbsTol
%             .stiff 
%% OUTPUT
% q1        - results of the Non-Linear eigenvalue problem action
% tt        - Time where the eigenfunction is computed 
% qq        - Eigenfunction in [0,ptds.T]
%% Reference:
%  W. Michiels and L. Fenzi, "Spectrum-based stability analysis and 
%  stabilization of a class of time-periodic time delay systems", 
%  arxiv.org/abs/1908.10280, (2019).
%
% Version 1.0, January, 2020. 
%                 Luca Fenzi.

d=ptds.dim; N=ptds.N;   % System Dimension
if options.stiff==0 && isscalar(ptds.mass)==1 && sum(sum(ptds.mass==0))==1
    %% Runge Kutta 4 (standalone implementation)
    if options.ode>0   
        M=options.ode; h=1/M; t=0; 
        q=zeros(N*d,M+1);  q(:,1)=q0;
        for k=1:M
            s1=h*DiffEq(t)*q(:,k);
            s2=h*DiffEq(t+h/2)*(q(:,k)+s1/2);
            s3=h*DiffEq(t+h/2)*(q(:,k)+s2/2);
            s4=h*DiffEq(t+h)*(q(:,k)+s3);
            q(:,k+1)=q(:,k)+(s1+2*s2+2*s3+s4)/6;
            t=t+h;
        end
        t=0:h:1;
    else   
    %% ODE45  (adaptive step size)
    tspan=[0,1];     options_ode = odeset('RelTol',options.RelTol,'AbsTol',options.AbsTol,'Jacobian', @(t,y) DiffEq(t));
    [t,q] = ode45(@(t,q) DiffEq(t)*q, tspan, q0,options_ode);
    q=transpose(q); t=transpose(t);
    end
else  
    if sum(sum(ptds.mass==0))==1,     E=eye(ptds.N*d);
    else,                             E=ptds.mass;
    end
    %% TRAPEZOIDAL RULE (standalone implementation)    
    if options.ode>0  
    M=options.ode; h=1/M; t=0:h:1;
    q=zeros(N*d,M+1);    q(:,1)=q0;
    for k=1:M
        q(:,k+1)=(E-h*DiffEq(t(k+1))/2)\(E*q(:,k)+h*DiffEq(t(k+1))*q(:,k)/2);
    end
    %% ODE15s (adaptive step size)
    else
      options_ode = odeset('Mass',E,'MassSingular','no','RelTol',options.RelTol,'AbsTol',options.AbsTol,'Jacobian', @(t,y) DiffEq(t));
      [t,q] = ode15s(@(t,q) DiffEq(t)*q,[0,1],q0,options_ode);    
      q=transpose(q);
    end
end

B=kron([zeros(N-1,1),eye(N-1);mu, zeros(1,N-1)],eye(d));
q1=q(:,end)-B*q0;       % residual of the non-linear eigenproblem
if nargout>1            % Eigenfunction
    M=length(t); qq=zeros(d,M*N); tt=zeros(1,M*N);
    for n=1:N
        qq(:,(M*(n-1)+1):(M*n))=q((d*(n-1)+1):d*n,:);
        tt((M*(n-1)+1):(M*n))=(ptds.T/N)*(n-1)+(ptds.T/N)*t;
    end
end


%% SYSTEM DEFINTION (Nested Function)
    function Amu = DiffEq(t)
    Amu=zeros(d*N,d*N);  
    for ell=1:N, row=(ell-1)*d+1:ell*d;
        for j=1:ptds.h, col=(ptds.ind(ell,j)-1)*d+1:ptds.ind(ell,j)*d;
            Amu(row,col)=Amu(row,col)+ptds.A{j}((t+ell-1)*ptds.T/N,K)*mu^(-ptds.exp(ell,j));
        end
    end
    Amu=(ptds.T/N)*Amu;
    end
end