% SCRIPT "UDDAE_heat_transfer_D2.m"
% The temperature of both coolers is affected by uncertainty.
% This script describes the mathematical model of the experimental heat
% transfer set-up proposed in [1] and tested with a deterministic 
% optimization in [2].
% The simulation obtained with this model are presented in [3, Section 5.3].
%
% Ex'(t)=sum_{i=1}^{h}A{i}(omega,K)*x(t-TAU{i}(omega))
%
% References:
% [1] T. Vyhlidal, P. Zitek and K. Paulu, "Design, modelling and control
%     of the experimental heat transfer set-up", in Loiseau et al. (Eds.),
%     Topics in Time Delay Systems Analysis, Algorithms, and Control, Lecture
%     Notes in Control and Information Sciences, Springer, New York, 2009, pp.
%     303-314.
% [2] W. Michiels, T. Vyhlidal, P. Zitek, "Control design for time-delay
%     systems based on quasi direct pole placement", Journal of Process Control
%     20: 337-343 (2010).
% [3] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%     delay systems in a probabilistic framework", Linear Algebra Appl. 
%     526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% SIZE OF THE LINEAR SYSTEM 
n=11;

extra.Inf=1;
extra.zeros=0;

%% NUMBER OF DISCRETE DELAYS
h=8;
%% LENGTH OF THE CONTROL PARAMETER
k=10;
%% STOCHASTIC DIMENSION OF THE PROBLEM
D=2;

%% DESCRIPTION OF THE RANDOM PARAMETERS
PCE=cell(1,D);
germ=cell(1,D);
    % germ{1}='u'; % Input 'u' or 'n' or 'e'
    % PCE{1}=[];  % Vector with the PCE w.r.t. to the germ{1}
    % ...
    % germ{D}='u'; % Input 'u' or 'n' or 'e'
    % PCE{D}=[];  % Vector with the PCE w.r.t. to the germ{D}


%% Define Model Parameters
Trd1    = 5;
Krd1    = 0.973;
tau_rd1 = 15;

Trh         = 25;
Krh1        = 0.96;
Krh2        = 0.536;
tau_rh1     = 23;
tau_rh2     = 11.5;

Trd2        = 5;
Krd2        = 0.983;
tau_rd2     = 5;

Tre         = 3;
kappa_re    = 0.85;

Trd3        = 5;
Krd3        = 0.975;
tau_rd3     = 3;

% Trc         = 17;       %Uncertain (+/- 10%)
    germ{2}='u'; % Input 'u' or 'n' or 'e'
    PCE{2}=[17, 1.7];
Krc1        = 0.9;      %Uncertain (+/- 20%)
Krc2        = 0.043;    %Uncertain (+/- 20%)
tau_rc1     = 5;
tau_rc2     = 6;

Tll         = 63;
tau_ll1     = 29;
tau_ll2     = 7;

Tle         = 3;
kappa_le    = 0.85;

Tld         = 5;
Kld         = 0.97;
tau_ld      = 5;

Tlc         = 15;       %Uncertain (+/- 10%)
    germ{1}='u'; % Input 'u' or 'n' or 'e'
    PCE{1}=[15, 1.5];
Klc1        = 0.92;     %Uncertain (+/- 20%)  
Klc2        = 0.042;    %Uncertain (+/- 20%)
tau_lc1     = 5;
tau_lc2     = 6;


%% LEADING MATRIX
E=diag([1,1,1,1,1,1,1,1,1,1,0]);



%% DISCRETE DELAY TERMS
TAU=@(omega) [0 3 5 6 7 15 23 29]; %INPUT discrete delays row vector TAU=[tau_{1}(omega),...,tau_{h}(omega)]>=0

A=cell(1,h);
% 1st matrix              DELAY 0
A0 = zeros(9,10); 
A0(1,1) = -1/Trd1; A0(2,2) = -1/Trh; A0(3,3) = -1/Trd2; A0(4,3) = (1-0.5*kappa_re)/Tre;
A0(4,4) = -(1+0.5*kappa_re)/Tre; A0(4,7) = kappa_re/2/Tre; A0(4,8) = kappa_re/2/Tre;
A0(5,5) = -1/Trd3; 
        % A0(6,6) = -1/Trc;         % Uncertainty 2
A0(8,3) = kappa_le/2/Tle; A0(8,4) = kappa_le/2/Tle;
A0(8,7) = (1-0.5*kappa_le)/Tle; A0(8,8) = -(1+0.5*kappa_le)/Tle; A0(9,9) = -1/Tld;
        % A0(10,10) = -1/Tlc;       % Uncertainty 1

A{1}=@(omega,K) [A0(1:5,:),  zeros(5,1); 
                zeros(1,5), -1/omega(2), zeros(1,5);
                A0(7:9,:), zeros(3,1);
                zeros(1,9), -1/omega(1), 0;
                 K(1), K(2), K(3), K(4), K(5), K(6), K(7), K(8), K(9), K(10), -1]; %INPUT: nxn matrix 
             
% 2nd Matrix              DELAY 3
             
A1=zeros(10); A1(5,4) = Krd3/Trd3;
A{2}=@(omega,K) [A1,zeros(10,1); 
                zeros(1,11)];

% 3rd Matrix               DELAY 5
A2 = zeros(9,10); A2(3,2) = Krd2/Trd2;
        % A2(6,5) = Krc1/Trc; % Uncertainty 2
                A2(9,8) = Kld/Tld;
        % A2(10,9) = Klc1/Tlc; % Uncertainty 1
A{3}=@(omega,K) [A2(1:5,:),zeros(5,1); 
    zeros(1,4), Krc1/omega(2), zeros(1,6);
    A2(7:9,:),zeros(3,1);
    zeros(1,8), Klc1/omega(1), zeros(1,2);
    zeros(1,11)];

% 4th Matrix               DELAY 6
%B1=zeros(10,1); B1(10)=Klc2/Tlc;
A{4}=@(omega,K) [zeros(9,10), zeros(9,1);
    zeros(1,10), Klc2/omega(1);
                zeros(1,11)];

% 5th Matrix               DELAY 7
B2=zeros(10,1); B2(7)=1/Tll;
A{5}=@(omega,K) [zeros(10,10), B2;
                zeros(1,11)];

% 6th Matrix               DELAY 15
A3=zeros(10); A3(1,6) = Krd1/Trd1;
A{6}=@(omega,K)[A3,zeros(10,1); 
                zeros(1,11)];

% 7th Matrix               DELAY 23
A4=zeros(10); A4(2,1) = Krh1/Trh;
A{7}=@(omega,K) [A4,zeros(10,1); 
                zeros(1,11)];

% 8th Matrix               DELAY 29
A5=zeros(10); A5(7,7) = -1/Tll;
A{8}=@(omega,K) [A5,zeros(10,1); 
                zeros(1,11)];


%% DERIVATIVES OF A{i} w.r.t K
A_prime=cell(k,h);
for i=1:k
    K_prime=zeros(1,11); K_prime(i)=1;
    A_prime{i,1}=@(omega,K) [zeros(10,11); K_prime];
    for j=2:h
        A_prime{i,j}=@(omega,K) zeros(11);
    end
end