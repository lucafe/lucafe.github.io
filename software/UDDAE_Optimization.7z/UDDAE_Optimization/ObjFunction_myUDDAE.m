function [f,df] = ObjFunction_myUDDAE(K,pars)
% OBJECTIVE FUNCTION myUDDAE
%  This function describes the objective function which is evaluated using
%  HANSO 
%  See function Optimization_myUDDAE to have more information
%  
%  This function is similar to the function Momenta Spectral Abscissa
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

% Sample points
Xi=pars.Xi;
eval(pars.model);

% Parameter for the optimization
N=pars.N;
M=pars.M;

% Initialization
alpha=NaN(1,M);
d_alpha=NaN(k,M);


%% Inizialization to use the parallelized for loop of MATLAB
E=E; A=A; TAU=TAU; A_prime=A_prime; h=h; k=k; extra=extra;

for r=1:M
        % Negative values of the delays must be deleted.
    if sum(TAU(Xi(:,r))<0)>0 
       warning('The %dth sample of the delays presents negative values\n This realization is neglected', r)
    else
        % We fix the realization Xi(:,r) and we compute the spectral
        % abscissa and its derivative for the deterministic DDAE associated 
        % to the realization of the random input
        
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        % The realization of the delay is sorted
        [TAU_D,order]=sort(TAU(Xi(:,r)));
        for i=1:h
            A_D{i}=A{order(i)}(Xi(:,r),K);
            for j=1:k
                A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r));
            end
        end
        [alpha(r),d_alpha(:,r)] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N,extra,...
                    'max_iter', pars.max_iter, 'accuracy', pars.accuracy, 'test', pars.test);
    end
end

% Delection of Inf or NaN derivatives
% if the delays are negative we enter in this if condition
if sum(sum(isnan(d_alpha)))+sum(sum(isinf(d_alpha)))>0
    warning('Neglected %d NaN and %d Inf in the calculation of the derivative', length(Xi(:,all(isnan(d_alpha)))), length(Xi(:,all(isinf(d_alpha)))));
    r=size(d_alpha);
    index=zeros(1,r(2));
    for i=1:r(1)
        index=index+isnan(d_alpha(i,:))+isinf(d_alpha(i,:));
    end
    index=(index>0);
    for j=1:r(2)
        if index(j)==1
            d_alpha(:,j-sum(index(1:j))+1)=[];
            alpha(j-sum(index(1:j))+1)=[];
        end
    end
end

Mean=mean(alpha);
Variance=var(alpha);
% Value of the objective function
f=Mean+pars.c*Variance;

d_Mean=zeros(k,1);
d_Variance=zeros(k,1);
for j=1:k
    d_Mean(j)=mean(d_alpha(j,:));
    d_Variance(j)=2*(mean(alpha.*d_alpha(j,:))-Mean*d_Mean(j));
end
% Derivative of the objective function w.r.t. the control parameter
df=d_Mean+pars.c*d_Variance;

% VERIFICATION 
% Check if the rightmost eigenvalue is evaluated using N discretization
% point in the interval [-tau_h,0].
if pars.verification>0
    % Comparison with the maximal spectral abscissa found
    [~,r]=max(alpha);
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        % The realization of the delay is sorted
        [TAU_D,order]=sort(TAU(Xi(:,r)));
        for i=1:h
            A_D{i}=A{order(i)}(Xi(:,r),K);
            for j=1:k
                A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r));
            end
        end
        [Trial] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N+n,extra,...
            'max_iter',pars.max_iter,'accuracy',pars.accuracy,'test',pars.test+1);
        if Trial-alpha(r)>pars.accuracy*100
            warning('The difference between the spectral abscissa evaluated with N discretization points and N+n is %1.10f\n Increase the discretization point.', Trial-alpha(r))
        end
        if pars.verification>1
            % Comparison with the minimal spectral abscissa found
            [~,r]=min(alpha);
                A_D=cell(1,h);
                A_prime_D=cell(k,h);
                % The realization of the delay is sorted
                [TAU_D,order]=sort(TAU(Xi(:,r)));
                for i=1:h
                    A_D{i}=A{order(i)}(Xi(:,r),K);
                    for j=1:k
                    A_prime_D{j,i}=A_prime{j,order(i)}(Xi(:,r));
                    end
                end
            [Trial] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N+n,extra,...
            'max_iter',pars.max_iter,'accuracy',pars.accuracy,'test',pars.test+1);
            if Trial-alpha(r)>pars.accuracy*100
                warning('The difference between the spectral abscissa evaluated with N discretization points and N+n is %1.10f\n Increase the discretization point.', Trial-alpha(r))
            end
        end
end

end

