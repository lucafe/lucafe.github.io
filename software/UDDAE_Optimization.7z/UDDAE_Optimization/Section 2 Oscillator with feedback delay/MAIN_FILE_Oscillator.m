%% MAIN FILE 
% Example of calls.
% This script was used to evaluate the values in the third to the fifth
% columns in Table 1, Section 2 of [1] and the values in the third columns 
% in Table 2, Section 3.1 of [1].
%
% REMEMBER TO LOAD THE HANSO PROGRAM 
% free download at http://www.cs.nyu.edu/overton/software/hanso/
% e.g. addpath('/home/luca/hanso') 
%
% REMEMBER TO LOAD the UDDAE CODES
% free download at https://people.cs.kuleuven.be/~luca.fenzi/LF_Software.htm
% e.g. addpath('/home/luca/UDDAE') 
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% 1 - LOAD HANSO 
% http://www.cs.nyu.edu/overton/software/hanso/
% addpath('/home/luca/hanso') 

%% 2 - LOAD UDDAE
% https://people.cs.kuleuven.be/~luca.fenzi/LF_Software.htm
% addpath('/home/luca/UDDAE')
addpath(fileparts(pwd))

%% 3 - SPECIFY YOUR MODEL
myUDDAE='UDDAE_Oscillator';
eval(myUDDAE)

%% 4 - SPECIFY THE PARAMETER OF THE OPTIMIZATION PROBLEM
M_opt=100;   % Number of sample that we use for the optimization problem
N=20;       % Number of discretization points used in the Infinitesimal
            % Generator approach
c=[0, 10, 100,1000];
            
%% 5 - SPECIFY THE PARAMETER OF THE POSTPROCESSING ANALYSIS
M_post=1000; % Number of sample that we use for the postprocessing analysis

% INITIALIZATION
K=zeros(k,length(c));           % Optimal controller
f=zeros(1,length(c));           % Optimal value of the Objective function
Mean=zeros(1,length(c));        % Mean spectral abscissa
Variance=zeros(1,length(c));    % Variance spectral abscissa
d_Mean=zeros(k,length(c));      % Derivative mean spectral abscissa w.r.t. K
d_Variance=zeros(k,length(c));  % Derivative Variance spectral abscissa w.r.t. K
alpha=zeros(1,length(c));       % Nominal value of the spectral abscissa
d_alpha=zeros(k,length(c));     % Nominal value of the gradient of the spectral abscissa

for i=1:length(c)
    % Settings for HANSO
    [pars,options] = Optimization_myUDDAE(myUDDAE, c(i), M_opt, N);
    % HANSO optimization
    [K(:,i),f(i)] = hanso(pars, options); 
    % Postprocessing analysis
    [Mean(i),Variance(i), d_Mean(:,i), d_Variance(:,i)]  =  MomentaSpectralAbscissa(myUDDAE, K(:,i), M_post, N);
    % Nominal Value
    [alpha(i),d_alpha(:,i)] =  NominalValue(myUDDAE, K(:,i), N);
end

%% REMARK 
% Mean+c.Variance should be comparable with f otherwise you should re-run
% the optimization function with more sampling points.

save('RESULTS_OSCILLATOR.mat','myUDDAE','c','M_opt','M_post','N',...
    'Mean','Variance','K','f','d_Mean','d_Variance','alpha','d_alpha');

%% BEHAVIOUR OF THE SPECTRAL ABSCISSA (Figure 1 in [1, Section 2])
% Bifurcation plot
myUDDAE='UDDAE_Oscillator';
eval(myUDDAE)
N=20;

% Different cases
cases=cell(1,3);
cases{1}='SAE';
cases{2}='MSSAEs';
cases{3}='MNSSAEs';

% Optimal gain values [1, Table 2]
K=cell(1,3);
K{1}=[0.2, 0.2];
K{2}=[0.5105, -0.0918];
K{3}=[0.6179, -0.0072];

% Uncertain parameters
omega=cell(1,2);
omega{1}=0.9:0.001:1.1; % nu is varying
omega{2}=0.15;          % fixed

alpha=cell(1,3);
for i=1:3
    alpha{i}=zeros(1,length(omega{1}));
    for j=1:length(omega{1})
        A_D=cell(1,h);
        A_prime_D=cell(k,h);
        TAU_D=TAU([omega{1}(j), omega{2}]);
        for hi=1:h
            A_D{hi}=A{hi}([omega{1}(j), omega{2}],K{i});
            for kj=1:k
                A_prime_D{kj,hi}=A_prime{kj,hi}([omega{1}(j), omega{2}],K{i});
            end
        end
        [alpha{i}(j)] = SpectralAbscissa(E,A_D,TAU_D,A_prime_D,N,extra);
    end
end
figure 
for i=1:3
    subplot(1,3,i)
    plot(omega{1}, alpha{i})
    title(cases{i})
end
