% SCRIPT myUDDAE='UDDE_Distributed_Delays';
%
% This script defines the System described in [1, Section 7] and in
% [2,Section 5.2]
%
% References:
%  [1] W. Michiels, K. Engelborghs, P. Vansevenant, D. Roose, "Continuous 
%      pole placement for delay equations", Automatica 38:
%      747-761, 2002.
%  [2] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% SIZE OF THE LINEAR SYSTEM 
n=7;

extra.Inf=1;
extra.zeros=3;

%% NUMBER OF DISCRETE DELAYS
h=3;

%% LENGTH OF THE CONTROL PARAMETER
k=3;

%% STOCHASTIC DIMENSION OF THE PROBLEM
D=2;

%% DESCRIPTION OF THE RANDOM PARAMETERS
PCE=cell(1,D);
germ=cell(1,D);
    germ{1}='u';    % Discrete Delay
    PCE{1}=[6,0.1];
    germ{2}='u';    % A{1}(1,1)
    PCE{2}=[0.1,0.025];
    

    
%% LEADING MATRIX
E=[ 1, 0, 0, 0, 0, 0, 0;...
    0, 1, 0, 0, 0, 0, 0;...
    0, 0, 1, 0, 0, 0, 0;...
    0, 0, 0, 1, 0, 0, 0;...
    0, 0, 0, 0, 1, 0, 0;...
    0, 0, 0, 0, 0, 1, 0;...
    0, 0, 0, 0, 0, 0, 0];

%% DISCRETE DELAY TERMS
TAU=@(omega) [0,1,omega(1)]; %INPUT discrete delays row vector TAU=[tau_{1}(omega),...,tau_{h}(omega)]>=0

% Matrices of DDE (25)
A1= [0.1,    0,    0;...
     0.2,    0, -0.2;...
      0.3,  0.1, -0.2];
A2=  [-0.2,    0,    0;...
      -0.4, -0.2,  0.4;...
      -0.4, -0.1,  0.2];
A3=  [ 0.1, -0.2,   0;...
        0,  0.1, 0.1;...
      -0.1,    0, 0.1];

% system (27)
A=cell(1,h);
A{1}=@(omega,K) [   A1,   eye(3), zeros(3,1);...
                    A3, zeros(3), zeros(3,1);...
                    K(1), K(2), K(3),  0,    0,   0, -1]; 

A{2}=@(omega,K) [   zeros(1,6), omega(2);...
                    zeros(3,7);...
                     zeros(3,7)]; 
                 
A{3}=@(omega,K) [   A2, zeros(3,4);...
                   -A3, zeros(3,4);...
                  zeros(1,7)];  

              %% DERIVATIVES OF A{i} w.r.t K
A_prime=cell(k,h);
    % Derivive of A{i} w.r.t. K(1)
A_prime{1,1}=@(omega,K) [zeros(6,7);
                         1, 0, 0, zeros(1,4)]; 
A_prime{1,2}=@(omega,K) zeros(7);
A_prime{1,3}=@(omega,K) zeros(7);
    % Derivive of A{i} w.r.t. K(2)
A_prime{2,1}=@(omega,K) [zeros(6,7);
                         0, 1, 0, zeros(1,4)]; 
A_prime{2,2}=@(omega,K) zeros(7);
A_prime{2,3}=@(omega,K) zeros(7);
    % Derivive of A{i} w.r.t. K(3)
A_prime{3,1}=@(omega,K) [zeros(6,7);
                         0, 0, 1, zeros(1,4)]; 
A_prime{3,2}=@(omega,K) zeros(7);
A_prime{3,3}=@(omega,K) zeros(7);