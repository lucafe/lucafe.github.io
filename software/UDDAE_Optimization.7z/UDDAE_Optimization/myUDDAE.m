% SCRIPT "myUDDAE.m"
%
% This script defines  the system of n linear
% Uncertian Delay Differential Algebraic Equations (UDDAEs):
%
% Ex'(t)=sum_{i=1}^{h}A{i}(omega,K)*x(t-TAU{i}(omega))
%
% where 
% - E       is the leading matrix 
% - A{i}    matrices corresponding to delay term TAU(i)
% - omega   random vector
% - K       parametrization of the controller
%
% In this script you should specify also:
% - n       dimension of the linear system
% - h       maximum number of delay (TAU=0 is considered a delay)
% - k       dimension of the controller (k==lenght(K))
% - D       stochastic dimension of the problem (D==length(omega))
% - germ{d} germ of the polynomial chaos expansion of every random variable
%           d=1,...,D
%           The value which can be assume are:
%           'u' Uniform distribution in [-1,1]
%           'n' Standard normal distribution with mean 1 and variance 1
%           'e' Exponential distribution with mean 1
% - PCE{d}  Vector which describe the polynomial chaos expansion w.r.t. to
%           the germ germ{d} for d=1,...,D
% - A_prime{j,i} Derivative of the matrix A{i} w.r.t. to K(j)
%           for i=1,...,h and j=1,...,k
% -extra.Inf n-rank of the leading matrix
%           Corresponds to the number of infinities that must be deleted.
% -extra.zeros Zeros non-phisical eigenvalues which arise considering 
%           distributed delays and must be deleted. 
%
% The script can be used in
% -'Optimization_myUDDAE'    Optimization algorithm 
% -'MomentaSpectralAbscissa' Post-processor algorithm
% -'Nominal Value'           Analysis of deterministic solutions
%
%  EXAMPLE:
% 'myUDDAE_Oscillator' Script which describes the Oscillator with feedback
%            delay.
%
% References:
%  [1] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% SIZE OF THE LINEAR SYSTEM 
n=[];

%% NUMBER OF DISCRETE DELAYS
h=[];

%% LENGTH OF THE CONTROL PARAMETER
k=[];

%% STOCHASTIC DIMENSION OF THE PROBLEM
D=[];

%% DESCRIPTION OF THE RANDOM PARAMETERS
PCE=cell(1,D);
germ=cell(1,D);
    germ{1}=''; % Input 'u' or 'n' or 'e'
    PCE{1}=[];  % Vector with the PCE w.r.t. to the germ{1}
    % ...
    germ{D}=''; % Input 'u' or 'n' or 'e'
    PCE{D}=[];  % Vector with the PCE w.r.t. to the germ{D}

%% NUMBER OF zeros & INF EIGENVALUES WHICH MUST BE DELETED
extra.Inf=[];    % n-rank of the leading matrix
extra.zeros=[];  % number of non-physical zero eigenvalues which arise
                 % differentiating the distributed delay.    
    
%% LEADING MATRIX
E=[];  %INPUT: nxn matrix 

%% DISCRETE DELAY TERMS
TAU=@(omega) []; %INPUT discrete delays row vector TAU=[tau_{1}(omega),...,tau_{h}(omega)]>=0

A=cell(1,h);
A{1}=@(omega,K) []; %INPUT: nxn matrix 
% ...
A{h}=@(omega,K) []; %INPUT: nxn matrix 

%% DERIVATIVES OF A{i} w.r.t K
A_prime=cell{k,h};
    % Derivive of A{i} w.r.t. K(1) for i=1,..,h
A_prime{1,1}=@(omega,K) [];
A_prime{1,h}=@(omega,K) [];
% ...

% Derivive of A{i} w.r.t. K(k) for i=1,...,k
A_prime{k,1}=@(omega,K) [];
A_prime{k,h}=@(omega,K) [];