% SCRIPT myUDDAE='UDDAE_NC0_Static';
%
% This script defines the System described in [1, Section 5] and in
% [2,Section 5.1]
%
% References:
%  [1] W. Michiels, K. Engelborghs, P. Vansevenant, D. Roose, "Continuous 
%      pole placement for delay equations", Automatica 38:
%      747-761, 2002.
%  [2] L. Fenzi and W. Michiels, "Robust stability optimization for linear 
%      delay systems in a probabilistic framework", Linear Algebra Appl. 
%      526: 1-26, 2017.
%
% Version 1.5, April, 2018. 
%               Luca Fenzi

%% SIZE OF THE LINEAR SYSTEM 
n=4;

%% NUMBER OF DISCRETE DELAYS
h=2;

%% LENGTH OF THE CONTROL PARAMETER
k=3;

%% STOCHASTIC DIMENSION OF THE PROBLEM
D=3;

%% DESCRIPTION OF THE RANDOM PARAMETERS
PCE=cell(1,D);
germ=cell(1,D);
    germ{1}='u';    % Discrete Delay
    PCE{1}=[5,0.1];
    germ{2}='u';    % A{1}(1,1)
    PCE{2}=[-0.08,0.01];
    germ{3}='u';    % A{1}(2,1)
    PCE{3}=[0.2,0.05];

    %% NUMBER OF zeros & INF EIGENVALUES WHICH MUST BE DELETED
extra.Inf=1;    % n-rank of the leading matrix
extra.zeros=0;  % number of non-physical zeri eigenvalues 
                % which arise differentiating the distributed delay.
    
%% LEADING MATRIX
E=[ 1, 0, 0, 0;...
    0, 1, 0, 0;...
    0, 0, 1, 0;...
    0, 0, 0, 0];

%% DISCRETE DELAY TERMS
TAU=@(omega) [0,omega(1)]; %INPUT discrete delays row vector TAU=[tau_{1}(omega),...,tau_{h}(omega)]>=0

A=cell(1,h);
A{1}=@(omega,K) [omega(2),  -0.03,     0.2,    0;...
                omega(3),   -0.04,  -0.005,    0;...
                   -0.06,     0.2,   -0.07,    0;...
                     K(1),    K(2),    K(3),  -1];  
A{h}=@(omega,K) [0, 0, 0, -0.1;...
                 0, 0, 0, -0.2;...
                 0, 0, 0,  0.1;...
                 0, 0, 0,    0]; 

%% DERIVATIVES OF A{i} w.r.t K
A_prime=cell(k,h);
    % Derivive of A{i} w.r.t. K(1)
A_prime{1,1}=@(omega,K) [0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         1, 0, 0, 0];
A_prime{1,2}=@(omega,K) zeros(4);
    % Derivive of A{i} w.r.t. K(2)
A_prime{2,1}=@(omega,K) [0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         0, 1, 0, 0];
A_prime{2,2}=@(omega,K) zeros(4);
    % Derivive of A{i} w.r.t. K(3)
A_prime{3,1}=@(omega,K) [0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         0, 0, 0, 0;...
                         0, 0, 1, 0];
A_prime{3,2}=@(omega,K) zeros(4);